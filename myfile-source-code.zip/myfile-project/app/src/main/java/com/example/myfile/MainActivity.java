package com.example.myfile;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.myfile.data.model.FileItem;
import com.example.myfile.data.repository.FileRepository;
import com.example.myfile.data.repository.FileRepositoryImpl;
import com.example.myfile.domain.operation.CopyOperation;
import com.example.myfile.domain.operation.CreateFileOperation;
import com.example.myfile.domain.operation.CreateFolderOperation;
import com.example.myfile.domain.operation.DeleteOperation;
import com.example.myfile.domain.operation.FileOperation;
import com.example.myfile.domain.operation.MoveOperation;
import com.example.myfile.domain.operation.RenameOperation;
import com.example.myfile.ui.main.FileAdapter;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements FileAdapter.OnItemClickListener {

    private FileRepository fileRepository;
    private FileAdapter adapter;
    private TextView tvCurrentPath;
    private LinearLayout emptyState;
    private String rootPath;
    private String currentPath;
    private String cutSourcePath = null;
    private String pendingSourcePath = null;
    private static final int MOVE_REQUEST_CODE = 200;
    private static final int COPY_REQUEST_CODE = 201;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fileRepository = new FileRepositoryImpl();
        tvCurrentPath = findViewById(R.id.tvCurrentPath);
        emptyState = findViewById(R.id.emptyState);

        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new FileAdapter(new ArrayList<>(), this);
        recyclerView.setAdapter(adapter);

        rootPath = Environment.getExternalStorageDirectory().getAbsolutePath();
        checkPermissionAndLoad();

        findViewById(R.id.btnNewFolder).setOnClickListener(v -> showCreateFolderDialog());
        findViewById(R.id.btnNewFile).setOnClickListener(v -> showCreateFileDialog());
        findViewById(R.id.btnPaste).setOnClickListener(v -> pasteFile());

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (!currentPath.equals(rootPath)) {
                    File parent = new File(currentPath).getParentFile();
                    if (parent != null) {
                        loadFiles(parent.getAbsolutePath());
                    } else {
                        loadFiles(rootPath);
                    }
                } else {
                    setEnabled(false);
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }
        });
    }

    private void checkPermissionAndLoad() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (Environment.isExternalStorageManager()) {
                loadFiles(rootPath);
            } else {
                Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                intent.setData(Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, 100);
            }
        } else {
            boolean readGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
            boolean writeGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
            if (readGranted && writeGranted) {
                loadFiles(rootPath);
            } else {
                ActivityCompat.requestPermissions(this, new String[]{
                        Manifest.permission.READ_EXTERNAL_STORAGE,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE
                }, 101);
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100 && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (Environment.isExternalStorageManager()) {
                loadFiles(rootPath);
            } else {
                Toast.makeText(this, "Permission denied, cannot read files", Toast.LENGTH_LONG).show();
            }
        } else if (requestCode == MOVE_REQUEST_CODE) {
            if (resultCode == RESULT_OK && data != null && pendingSourcePath != null) {
                String destPath = data.getStringExtra(FolderPickerActivity.EXTRA_SELECTED_PATH);
                FileOperation operation = new MoveOperation(fileRepository, pendingSourcePath, destPath);
                runOperation(operation, "Moved successfully", "Move failed");
            }
            pendingSourcePath = null;
        } else if (requestCode == COPY_REQUEST_CODE) {
            if (resultCode == RESULT_OK && data != null && pendingSourcePath != null) {
                String destPath = data.getStringExtra(FolderPickerActivity.EXTRA_SELECTED_PATH);
                FileOperation operation = new CopyOperation(fileRepository, pendingSourcePath, destPath);
                runOperation(operation, "Copied successfully", "Copy failed");
            }
            pendingSourcePath = null;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 101 && grantResults.length >= 2
                && grantResults[0] == PackageManager.PERMISSION_GRANTED
                && grantResults[1] == PackageManager.PERMISSION_GRANTED) {
            loadFiles(rootPath);
        } else {
            Toast.makeText(this, "Permission denied, cannot read/write files", Toast.LENGTH_LONG).show();
        }
    }

    private void loadFiles(String path) {
        currentPath = path;
        tvCurrentPath.setText(path);
        List<FileItem> items = fileRepository.list(path);
        adapter.updateData(items);
        emptyState.setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);
    }

    @Override
    public void onItemClick(FileItem item) {
        if (item.isDirectory()) {
            loadFiles(item.getPath());
        } else {
            Toast.makeText(this, "Open file: " + item.getName() + " (viewer not implemented yet)", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onItemLongClick(FileItem item) {
        String[] options = {"Rename", "Move", "Copy", "Cut", "Delete", "Properties"};
        new AlertDialog.Builder(this)
                .setTitle(item.getName())
                .setItems(options, (dialog, which) -> {
                    if (which == 0) {
                        showRenameDialog(item);
                    } else if (which == 1) {
                        showMoveDialog(item);
                    } else if (which == 2) {
                        showCopyDialog(item);
                    } else if (which == 3) {
                        cutSourcePath = item.getPath();
                        Toast.makeText(this, item.getName() + " cut. Navigate to destination and tap Paste.", Toast.LENGTH_SHORT).show();
                    } else if (which == 4) {
                        showDeleteConfirm(item);
                    } else {
                        showPropertiesDialog(item);
                    }
                })
                .show();
    }

    private void runOperation(FileOperation operation, String successMessage, String failMessage) {
        boolean ok = operation.execute();
        Toast.makeText(this, ok ? successMessage : failMessage, Toast.LENGTH_SHORT).show();
        loadFiles(currentPath);
    }

    private void showRenameDialog(FileItem item) {
        EditText input = new EditText(this);
        input.setText(item.getName());
        new AlertDialog.Builder(this)
                .setTitle("Rename")
                .setView(input)
                .setPositiveButton("OK", (d, w) -> {
                    String newName = input.getText().toString().trim();
                    if (newName.isEmpty()) {
                        Toast.makeText(this, "Name cannot be empty", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    FileOperation operation = new RenameOperation(fileRepository, item.getPath(), newName);
                    runOperation(operation, "Renamed successfully", "Rename failed (name already exists?)");
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showMoveDialog(FileItem item) {
        pendingSourcePath = item.getPath();
        Intent intent = new Intent(this, FolderPickerActivity.class);
        intent.putExtra(FolderPickerActivity.EXTRA_START_PATH, currentPath);
        startActivityForResult(intent, MOVE_REQUEST_CODE);
    }

    private void showCopyDialog(FileItem item) {
        pendingSourcePath = item.getPath();
        Intent intent = new Intent(this, FolderPickerActivity.class);
        intent.putExtra(FolderPickerActivity.EXTRA_START_PATH, currentPath);
        startActivityForResult(intent, COPY_REQUEST_CODE);
    }

    private void pasteFile() {
        if (cutSourcePath == null) {
            Toast.makeText(this, "Nothing to paste. Cut a file first.", Toast.LENGTH_SHORT).show();
            return;
        }
        FileOperation operation = new MoveOperation(fileRepository, cutSourcePath, currentPath);
        boolean ok = operation.execute();
        Toast.makeText(this, ok ? "Pasted successfully" : "Paste failed", Toast.LENGTH_SHORT).show();
        if (ok) {
            cutSourcePath = null;
        }
        loadFiles(currentPath);
    }

    private void showDeleteConfirm(FileItem item) {
        String message;
        if (item.isDirectory()) {
            message = "This will delete everything inside.";
        } else {
            message = "This action cannot be undone.";
        }
        new AlertDialog.Builder(this)
                .setTitle("Delete " + item.getName() + "?")
                .setMessage(message)
                .setPositiveButton("Delete", (d, w) -> {
                    FileOperation operation = new DeleteOperation(fileRepository, item.getPath());
                    runOperation(operation, "Deleted successfully", "Delete failed");
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showPropertiesDialog(FileItem item) {
        String type = item.isDirectory() ? "Folder" : "File";
        String sizeText = formatSize(item.getSize());
        String dateText = new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", java.util.Locale.getDefault()).format(item.getLastModified());

        String itemCountText = "";
        if (item.isDirectory()) {
            File folder = new File(item.getPath());
            File[] children = folder.listFiles();
            int count = children != null ? children.length : 0;
            itemCountText = "\nItems inside: " + count;
        }

        String message = "Name: " + item.getName()
                + "\nType: " + type
                + "\nPath: " + item.getPath()
                + "\nSize: " + sizeText
                + "\nLast modified: " + dateText
                + itemCountText;

        new AlertDialog.Builder(this)
                .setTitle("Properties")
                .setMessage(message)
                .setPositiveButton("OK", null)
                .show();
    }

    private String formatSize(long bytes) {
        if (bytes < 1024) {
            return bytes + " B";
        }
        int exp = (int) (Math.log(bytes) / Math.log(1024));
        String unit = "KMGTPE".charAt(exp - 1) + "B";
        return String.format(java.util.Locale.getDefault(), "%.1f %s", bytes / Math.pow(1024, exp), unit);
    }

    private void showCreateFolderDialog() {
        EditText input = new EditText(this);
        input.setHint("Folder name");
        new AlertDialog.Builder(this)
                .setTitle("New Folder")
                .setView(input)
                .setPositiveButton("Create", (d, w) -> {
                    String folderName = input.getText().toString().trim();
                    if (folderName.isEmpty()) {
                        Toast.makeText(this, "Name cannot be empty", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    FileOperation operation = new CreateFolderOperation(fileRepository, currentPath, folderName);
                    runOperation(operation, "Folder created", "Create failed (name already exists?)");
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showCreateFileDialog() {
        EditText input = new EditText(this);
        input.setHint("File name (e.g. note.txt)");
        new AlertDialog.Builder(this)
                .setTitle("New File")
                .setView(input)
                .setPositiveButton("Create", (d, w) -> {
                    String fileName = input.getText().toString().trim();
                    if (fileName.isEmpty()) {
                        Toast.makeText(this, "Name cannot be empty", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    FileOperation operation = new CreateFileOperation(fileRepository, currentPath, fileName);
                    runOperation(operation, "File created", "Create failed (name already exists?)");
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}
