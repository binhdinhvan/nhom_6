package com.example.myfile.ui.main;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.myfile.R;
import com.example.myfile.data.model.FileItem;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

public class FileAdapter extends RecyclerView.Adapter<FileAdapter.ViewHolder> {

    public interface OnItemClickListener {
        void onItemClick(FileItem item);
        void onItemLongClick(FileItem item);
    }

    private List<FileItem> items;
    private final OnItemClickListener listener;

    public FileAdapter(List<FileItem> items, OnItemClickListener listener) {
        this.items = items;
        this.listener = listener;
    }

    public void updateData(List<FileItem> newItems) {
        this.items = newItems;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_file, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        FileItem item = items.get(position);
        holder.tvName.setText(item.getName());

        if (item.isDirectory()) {
            holder.tvName.setTextColor(0xFF1976D2);
            holder.tvDetail.setText("Thu muc");
            holder.tvBadge.setText("DIR");
            holder.tvBadge.setBackgroundColor(0xFF1976D2);
        } else {
            holder.tvName.setTextColor(0xFF212121);
            String date = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(item.getLastModified());
            String sizeText = formatSize(item.getSize());
            holder.tvDetail.setText(sizeText + " - " + date);
            holder.tvBadge.setText(getBadgeText(item.getName()));
            holder.tvBadge.setBackgroundColor(getBadgeColor(item.getName()));
        }

        holder.itemView.setOnClickListener(v -> listener.onItemClick(item));
        holder.itemView.setOnLongClickListener(v -> {
            listener.onItemLongClick(item);
            return true;
        });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    private String getBadgeText(String name) {
        String lower = name.toLowerCase(Locale.getDefault());
        if (lower.endsWith(".jpg") || lower.endsWith(".jpeg") || lower.endsWith(".png")) {
            return "IMG";
        } else if (lower.endsWith(".mp4") || lower.endsWith(".avi") || lower.endsWith(".mkv")) {
            return "VID";
        } else if (lower.endsWith(".zip") || lower.endsWith(".rar")) {
            return "ZIP";
        } else if (lower.endsWith(".pdf")) {
            return "PDF";
        } else if (lower.endsWith(".txt")) {
            return "TXT";
        } else if (lower.endsWith(".mp3") || lower.endsWith(".wav")) {
            return "MP3";
        }
        return "FILE";
    }

    private int getBadgeColor(String name) {
        String lower = name.toLowerCase(Locale.getDefault());
        if (lower.endsWith(".jpg") || lower.endsWith(".jpeg") || lower.endsWith(".png")) {
            return 0xFF43A047;
        } else if (lower.endsWith(".mp4") || lower.endsWith(".avi") || lower.endsWith(".mkv")) {
            return 0xFF8E24AA;
        } else if (lower.endsWith(".zip") || lower.endsWith(".rar")) {
            return 0xFFFB8C00;
        } else if (lower.endsWith(".pdf")) {
            return 0xFFE53935;
        } else if (lower.endsWith(".txt")) {
            return 0xFF607D8B;
        } else if (lower.endsWith(".mp3") || lower.endsWith(".wav")) {
            return 0xFFD81B60;
        }
        return 0xFF90A4AE;
    }

    private String formatSize(long bytes) {
        if (bytes < 1024) {
            return bytes + " B";
        }
        int exp = (int) (Math.log(bytes) / Math.log(1024));
        String unit = "KMGTPE".charAt(exp - 1) + "B";
        return String.format(Locale.getDefault(), "%.1f %s", bytes / Math.pow(1024, exp), unit);
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvBadge;
        TextView tvName;
        TextView tvDetail;

        ViewHolder(View itemView) {
            super(itemView);
            tvBadge = itemView.findViewById(R.id.tvBadge);
            tvName = itemView.findViewById(R.id.tvName);
            tvDetail = itemView.findViewById(R.id.tvDetail);
        }
    }
}
