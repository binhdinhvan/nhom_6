# My File - Source code (Thanh vien B - Thao tac file)

File nay tong hop toan bo code Java/XML da viet trong qua trinh lam viec.
Day KHONG PHAI mot project Android Studio day du (khong co build.gradle,
gradlew, icon...) - chi la phan source code de copy vao project that.

## Cach dung

1. Mo project that (o cong ty hoac tao moi o nha voi package `com.example.myfile`).
2. Copy toan bo cay thu muc trong `app/src/main/java/...` va `app/src/main/res/layout/...`
   vao dung vi tri tuong ung trong project that (ghi de neu trung ten file).
3. Mo file `MANIFEST_ADDITIONS.txt`, them dung cac dong do vao `AndroidManifest.xml`
   that (phan quyen + khai bao FolderPickerActivity) - KHONG copy de AndroidManifest.xml
   vi file that co the co noi dung khac (icon, theme, ten app...).
4. Kiem tra `app/build.gradle.kts` co dong nay chua, neu chua them vao:
   `implementation("androidx.recyclerview:recyclerview:1.3.2")`
5. Sync Gradle, build thu (Ctrl+F9), roi push len git that.

## Danh sach file

- data/model/FileItem.java
- data/repository/FileRepository.java (interface)
- data/repository/FileRepositoryImpl.java
- domain/operation/ (Command pattern: FileOperation + Rename/Delete/Move/Copy/CreateFolder/CreateFile)
- ui/main/FileAdapter.java
- MainActivity.java
- FolderPickerActivity.java
- res/layout/activity_main.xml
- res/layout/activity_folder_picker.xml
- res/layout/item_file.xml

## Tinh nang da lam

- View / Open / Up one level
- Rename, Delete
- Move, Copy (chon thu muc dich qua FolderPickerActivity, khong can go tay path)
- Cut / Paste
- Create Folder, Create File
- Xem thuoc tinh (Properties)
- Kien truc: Command pattern (FileOperation), tach Repository/UI

## Con thieu (theo phan cong)

- Chon nhieu (multi-select)
- Hien thi tien trinh (progress bar)
- Chia se (share)
