package com.example.myfile.feature.archive;

import android.app.AlertDialog;
import android.content.Context;
import android.widget.EditText;
import android.widget.Toast;

/**
 * [C] Dialog nhap ten file zip truoc khi nen, dung android.app.AlertDialog +
 * EditText giong het phong cach showRenameDialog/showCreateFolderDialog cua
 * MainActivity (B), thay vi tao DialogFragment rieng (du an khong dung mau nay).
 */
public final class ArchiveDialogs {

    public interface OnZipNameConfirmed {
        void onConfirmed(String zipFileName);
    }

    private ArchiveDialogs() { }

    public static void showZipNameDialog(Context context, String suggestedBaseName, OnZipNameConfirmed listener) {
        EditText input = new EditText(context);
        input.setText(suggestedBaseName);
        input.setSelection(suggestedBaseName.length());

        new AlertDialog.Builder(context)
                .setTitle("Compress to .zip")
                .setView(input)
                .setPositiveButton("Compress", (d, w) -> {
                    String name = input.getText().toString().trim();
                    if (name.isEmpty()) {
                        Toast.makeText(context, "Name cannot be empty", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    String zipName = name.toLowerCase().endsWith(".zip") ? name : name + ".zip";
                    listener.onConfirmed(zipName);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}
