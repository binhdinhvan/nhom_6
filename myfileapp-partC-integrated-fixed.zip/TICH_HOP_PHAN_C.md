# Đã tích hợp phần C vào MyFileapp1

Bản zip này là TOÀN BỘ project MyFileapp1 gốc của bạn (đã bỏ `.gradle/` cache
và `local.properties` vì máy-cụ-thể, Android Studio sẽ tự tạo lại khi mở
project) + code phần C đã ghép sẵn, có thể mở bằng Android Studio và bấm
Run luôn (sau khi Sync Gradle lần đầu để tải PhotoView/Glide/ExoPlayer).

## Những gì đã thay đổi so với MyFileapp1 gốc

1. **File mới** — `util/`, `feature/viewer/`, `feature/archive/` + layout/drawable
   tương ứng (xem danh sách đầy đủ ở README_C.md nếu bạn cần, về cơ bản giống
   những gì đã trao đổi trước đó).

2. **`MainActivity.java`** — chỉ THÊM, không xoá dòng nào của bạn:
   - Field mới: `currentFlatItems` (danh sách file không header, dùng cho
     ViewerFactory vuốt ảnh/video).
   - `loadFiles()` và `loadRecentFiles()`: thêm 1 dòng lưu `currentFlatItems`
     trước khi gộp theo ngày (groupFilesByDate).
   - `onItemClick()`: gọi `ViewerFactory.open(this, item, currentFlatItems)`
     thay vì Toast "viewer not implemented yet".
   - `onItemLongClick()`: đổi từ mảng `String[]` cố định sang `List<String>`
     động, thêm "Zip" (luôn có) và "Unzip" (chỉ hiện khi item là file .zip).
     2 hàm mới `showZipDialog()` / `unzipHere()` dùng `runOperationWithProgress()`
     có sẵn của bạn (progress dialog, không code lại gì mới).

3. **`AndroidManifest.xml`** — thêm 4 dòng `<activity>` cho
   ImageViewerActivity/VideoPlayerActivity/ExifViewerActivity/TextViewerActivity.
   `<provider>` FileProvider giữ nguyên, KHÔNG thêm trùng.

4. **`app/build.gradle.kts`** — thêm 5 dòng dependency (Glide, PhotoView,
   ViewPager2, ExoPlayer, exifinterface).

5. **`settings.gradle.kts`** — thêm `maven { url = uri("https://jitpack.io") }`
   vào `dependencyResolutionManagement` (bắt buộc vì file này có
   `FAIL_ON_PROJECT_REPOS`, nếu thiếu dòng này Gradle sẽ báo lỗi "Could not
   find com.github.chrisbanes:PhotoView" khi sync).

## Đã tự kiểm tra trước khi gửi

- Cân bằng ngoặc `{}` của mọi file `.java` — OK
- Toàn bộ `.xml` qua `xmllint --noout` — OK, không lỗi cú pháp
- Mọi `R.id.*` trong Java của 4 màn hình viewer khớp đúng với id trong layout
  tương ứng — OK
- Mọi `R.drawable.*` (`ic_type_*`) đều có file thật trong `res/drawable/` — OK
- `ZipOperation`/`UnzipOperation` implement đúng `interface FileOperation`
  hiện có (`boolean execute()`) — khớp 100%, không cần sửa gì ở
  `runOperationWithProgress()`.
- Theme `Theme.MaterialComponents.DayNight.NoActionBar` — 4 activity mới
  không gọi `getSupportActionBar()`/`setSupportActionBar()` nên không crash.

## Việc bạn cần làm khi mở trong Android Studio

1. Mở project, để Android Studio tự tạo lại `local.properties` (trỏ SDK máy
   bạn) nếu nó hỏi.
2. **File > Sync Project with Gradle Files** — lần đầu sẽ tải PhotoView/Glide/
   ExoPlayer/exifinterface, cần mạng, có thể mất 1-2 phút.
3. Build thử (Ctrl+F9 / Build > Make Project).
4. Chạy trên máy ảo, bấm vào 1 ảnh để test ImageViewerActivity, long-click
   một file/thư mục để thấy nút "Zip", long-click 1 file `.zip` để thấy thêm
   nút "Unzip".

Nếu Gradle sync hoặc build vẫn báo lỗi, gửi nguyên văn thông báo lỗi cho tôi
(kèm số dòng nếu có) để tôi xử lý tiếp.
