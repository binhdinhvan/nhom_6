package com.example.myfile.feature.archive;

import android.app.Dialog;
import android.os.Bundle;
import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;

import com.example.myfile.R;
import com.example.myfile.databinding.DialogZipBinding;

/**
 * Dialog nhap ten file .zip truoc khi goi ArchiveViewModel.zip().
 * Dung theo mau cac dialog khac cua B (RenameDialog, NewFolderDialog...).
 */
public class ZipDialog extends DialogFragment {

    private static final String ARG_SUGGESTED_NAME = "arg_suggested_name";

    private DialogZipBinding binding;
    private OnZipNameConfirmedListener listener;

    public interface OnZipNameConfirmedListener {
        void onZipNameConfirmed(@NonNull String zipFileName);
    }

    public static ZipDialog newInstance(@NonNull String suggestedName,
                                        @NonNull OnZipNameConfirmedListener listener) {
        ZipDialog dialog = new ZipDialog();
        Bundle args = new Bundle();
        args.putString(ARG_SUGGESTED_NAME, suggestedName);
        dialog.setArguments(args);
        dialog.listener = listener;
        return dialog;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        binding = DialogZipBinding.inflate(getLayoutInflater());

        String suggested = getArguments() != null
                ? getArguments().getString(ARG_SUGGESTED_NAME, "archive") : "archive";
        String baseName = suggested.toLowerCase().endsWith(".zip")
                ? suggested.substring(0, suggested.length() - 4) : suggested;
        binding.editZipName.setText(baseName);
        binding.editZipName.setSelection(baseName.length());

        AlertDialog dialog = new AlertDialog.Builder(requireContext())
                .setTitle(R.string.zip_dialog_title)
                .setView(binding.getRoot())
                .setPositiveButton(R.string.action_zip, null) // gan listener sau de tu chan dismiss khi rong
                .setNegativeButton(R.string.action_cancel, (d, which) -> dismiss())
                .create();

        dialog.setOnShowListener(d -> {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> confirm());
        });

        return dialog;
    }

    private void confirm() {
        String name = binding.editZipName.getText() != null
                ? binding.editZipName.getText().toString().trim() : "";
        if (TextUtils.isEmpty(name)) {
            binding.editZipName.setError(getString(R.string.error_name_required));
            return;
        }
        String zipName = name.toLowerCase().endsWith(".zip") ? name : name + ".zip";
        if (listener != null) listener.onZipNameConfirmed(zipName);
        dismiss();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
