package com.example.myfile.feature.viewer.text;

import android.content.Context;
import android.content.Intent;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModelProvider;

import com.example.myfile.core.base.BaseActivity;
import com.example.myfile.core.model.FileItem;
import com.example.myfile.core.model.UiState;
import com.example.myfile.databinding.ActivityTextViewerBinding;

import dagger.hilt.android.AndroidEntryPoint;

/** [C] (optional) Xem nhanh noi dung file .txt/.log/.json/.md... */
@AndroidEntryPoint
public class TextViewerActivity extends BaseActivity<ActivityTextViewerBinding> {

    private static final String EXTRA_FILE_ITEM = "extra_file_item";

    private TextViewModel viewModel;

    public static void start(@NonNull Context context, @NonNull FileItem item) {
        Intent intent = new Intent(context, TextViewerActivity.class);
        intent.putExtra(EXTRA_FILE_ITEM, item);
        context.startActivity(intent);
    }

    @Override
    protected ActivityTextViewerBinding inflateBinding() {
        return ActivityTextViewerBinding.inflate(getLayoutInflater());
    }

    @Override
    protected void initViews() {
        setSupportActionBar(binding.toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        binding.toolbar.setNavigationOnClickListener(v -> finish());
        viewModel = new ViewModelProvider(this).get(TextViewModel.class);
    }

    @Override
    protected void observeData() {
        viewModel.getUiState().observe(this, this::onUiState);

        FileItem item = getIntent().getParcelableExtra(EXTRA_FILE_ITEM);
        if (item == null) {
            finish();
            return;
        }
        if (getSupportActionBar() != null) getSupportActionBar().setTitle(item.getName());
        viewModel.load(item);
    }

    private void onUiState(UiState<String> state) {
        switch (state.getStatus()) {
            case LOADING:
                binding.progressBar.setVisibility(View.VISIBLE);
                binding.textContent.setVisibility(View.GONE);
                break;
            case SUCCESS:
                binding.progressBar.setVisibility(View.GONE);
                binding.textContent.setVisibility(View.VISIBLE);
                binding.textContent.setText(state.getData());
                break;
            case EMPTY:
                binding.progressBar.setVisibility(View.GONE);
                binding.textContent.setVisibility(View.VISIBLE);
                binding.textContent.setText(com.example.myfile.R.string.text_viewer_empty);
                break;
            case ERROR:
                binding.progressBar.setVisibility(View.GONE);
                binding.textContent.setVisibility(View.VISIBLE);
                binding.textContent.setText(state.getMessage());
                break;
        }
    }
}
