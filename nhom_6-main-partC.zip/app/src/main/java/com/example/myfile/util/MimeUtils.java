package com.example.myfile.util;

import android.webkit.MimeTypeMap;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.myfile.core.model.FileType;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * [C] Util tinh: doan MIME type va FileType tu ten file.
 *
 * Day la ban "that" thay the DefaultFileTypeResolver (core B/A dung tam).
 * Duoc bind vao FileRepository qua {@link MimeUtilsFileTypeResolver}
 * (xem core/di/RepositoryModule.bindTypeResolver).
 *
 * Static, khong co state -> khong can DI, dung truc tiep tu bat ky dau
 * (Adapter, ViewerFactory, IconMapper...).
 */
public final class MimeUtils {

    private static final Set<String> IMAGE = set(
            "jpg", "jpeg", "png", "gif", "bmp", "webp", "heic", "heif", "svg");
    private static final Set<String> VIDEO = set(
            "mp4", "mkv", "avi", "mov", "3gp", "webm", "flv", "m4v", "ts");
    private static final Set<String> AUDIO = set(
            "mp3", "wav", "flac", "aac", "ogg", "m4a", "wma", "opus", "mid");
    private static final Set<String> ARCHIVE = set(
            "zip", "rar", "7z", "tar", "gz", "bz2", "xz");
    private static final Set<String> DOCUMENT = set(
            "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "odt", "ods", "odp");
    private static final Set<String> TEXT = set(
            "txt", "log", "json", "xml", "md", "csv", "ini", "conf", "java", "kt", "gradle");

    private MimeUtils() { /* static-only */ }

    /** Phan mo rong viet thuong, khong dau cham. "" neu khong co. */
    @NonNull
    public static String extensionOf(@Nullable String fileName) {
        if (fileName == null) return "";
        int dot = fileName.lastIndexOf('.');
        if (dot <= 0 || dot == fileName.length() - 1) return "";
        return fileName.substring(dot + 1).toLowerCase(Locale.ROOT);
    }

    /** Phan loai nghiep vu dua tren phan mo rong. */
    @NonNull
    public static FileType typeOf(@Nullable String fileName, boolean isDirectory) {
        if (isDirectory) return FileType.FOLDER;
        String ext = extensionOf(fileName);
        if (ext.isEmpty()) return FileType.OTHER;
        if (IMAGE.contains(ext))    return FileType.IMAGE;
        if (VIDEO.contains(ext))    return FileType.VIDEO;
        if (AUDIO.contains(ext))    return FileType.AUDIO;
        if (ARCHIVE.contains(ext))  return FileType.ARCHIVE;
        if (DOCUMENT.contains(ext)) return FileType.DOCUMENT;
        if (TEXT.contains(ext))     return FileType.TEXT;
        if ("apk".equals(ext))      return FileType.APK;
        return FileType.OTHER;
    }

    /**
     * MIME type thuc su cho file (dung cho Intent.ACTION_VIEW, FileProvider...).
     * Uu tien android.webkit.MimeTypeMap (day du hon bang tinh),
     * fallback ve nhom rong theo FileType neu he thong khong biet.
     */
    @NonNull
    public static String mimeTypeOf(@Nullable String fileName) {
        String ext = extensionOf(fileName);
        if (!ext.isEmpty()) {
            String system = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
            if (system != null) return system;
        }
        switch (typeOf(fileName, false)) {
            case IMAGE:    return "image/*";
            case VIDEO:    return "video/*";
            case AUDIO:    return "audio/*";
            case TEXT:     return "text/plain";
            case ARCHIVE:  return "application/zip";
            case APK:      return "application/vnd.android.package-archive";
            case DOCUMENT: return "application/octet-stream";
            default:       return "*/*";
        }
    }

    public static boolean isImage(@Nullable String fileName)   { return typeOf(fileName, false) == FileType.IMAGE; }
    public static boolean isVideo(@Nullable String fileName)   { return typeOf(fileName, false) == FileType.VIDEO; }
    public static boolean isArchive(@Nullable String fileName) { return typeOf(fileName, false) == FileType.ARCHIVE; }

    private static Set<String> set(String... values) {
        return new HashSet<>(Arrays.asList(values));
    }
}
