package com.example.myfile.feature.viewer.image;

import android.content.Context;
import android.content.Intent;
import android.view.Menu;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewpager2.widget.ViewPager2;

import com.example.myfile.R;
import com.example.myfile.core.base.BaseActivity;
import com.example.myfile.core.model.FileItem;
import com.example.myfile.databinding.ActivityImageViewerBinding;
import com.example.myfile.feature.viewer.exif.ExifViewerActivity;
import com.example.myfile.util.FileUtils;
import com.example.myfile.util.MimeUtils;

import java.util.ArrayList;

import dagger.hilt.android.AndroidEntryPoint;

/**
 * [C] Xem anh toan man hinh: Glide (giai ma) + PhotoView (zoom) + ViewPager2 (vuot).
 *
 * Nhan vao danh sach FileItem (chi anh, cung thu muc) + vi tri bat dau,
 * cho phep vuot trai/phai giua cac anh trong cung folder.
 */
@AndroidEntryPoint
public class ImageViewerActivity extends BaseActivity<ActivityImageViewerBinding> {

    private static final String EXTRA_IMAGES = "extra_images";
    private static final String EXTRA_START_INDEX = "extra_start_index";

    private ImagePagerAdapter adapter;
    private ArrayList<FileItem> images;

    public static void start(@NonNull Context context, @NonNull FileItem current,
                             @NonNull java.util.List<FileItem> siblings) {
        ArrayList<FileItem> onlyImages = new ArrayList<>();
        int startIndex = 0;
        for (FileItem f : siblings) {
            if (!f.isDirectory() && MimeUtils.isImage(f.getName())) {
                if (f.getPath().equals(current.getPath())) startIndex = onlyImages.size();
                onlyImages.add(f);
            }
        }
        if (onlyImages.isEmpty()) {
            onlyImages.add(current);
        }

        Intent intent = new Intent(context, ImageViewerActivity.class);
        intent.putParcelableArrayListExtra(EXTRA_IMAGES, onlyImages);
        intent.putExtra(EXTRA_START_INDEX, startIndex);
        context.startActivity(intent);
    }

    @Override
    protected ActivityImageViewerBinding inflateBinding() {
        return ActivityImageViewerBinding.inflate(getLayoutInflater());
    }

    @Override
    protected void initViews() {
        setSupportActionBar(binding.toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("");
        }
        binding.toolbar.setNavigationOnClickListener(v -> finish());

        images = getIntent().getParcelableArrayListExtra(EXTRA_IMAGES);
        if (images == null) images = new ArrayList<>();
        int startIndex = getIntent().getIntExtra(EXTRA_START_INDEX, 0);

        adapter = new ImagePagerAdapter();
        binding.viewPager.setAdapter(adapter);
        adapter.submitList(images);
        binding.viewPager.setCurrentItem(startIndex, false);

        updateCounter(startIndex);
        binding.viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                updateCounter(position);
            }
        });
    }

    private void updateCounter(int position) {
        if (images.isEmpty()) return;
        binding.textCounter.setText((position + 1) + " / " + images.size());
        setToolbarTitle(images.get(position).getName());
    }

    private void setToolbarTitle(String name) {
        if (getSupportActionBar() != null) getSupportActionBar().setTitle(name);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_image_viewer, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        FileItem current = currentItem();
        if (current == null) return super.onOptionsItemSelected(item);

        int id = item.getItemId();
        if (id == R.id.action_exif) {
            ExifViewerActivity.start(this, current);
            return true;
        } else if (id == R.id.action_share) {
            shareCurrent(current);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Nullable
    private FileItem currentItem() {
        if (images == null || images.isEmpty()) return null;
        int pos = binding.viewPager.getCurrentItem();
        if (pos < 0 || pos >= images.size()) return null;
        return images.get(pos);
    }

    private void shareCurrent(FileItem item) {
        android.net.Uri uri = FileUtils.contentUriFor(this, item.toFile());
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType(MimeUtils.mimeTypeOf(item.getName()));
        share.putExtra(Intent.EXTRA_STREAM, uri);
        share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(share, getString(R.string.action_share)));
    }
}
