package com.example.myfile.feature.viewer.exif;

import androidx.exifinterface.media.ExifInterface;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Tach rieng logic doc EXIF khoi Activity (de test doc lap va tai su dung).
 * Chi lam viec voi java.io.File -> chi duoc goi tu ViewModel/helper,
 * KHONG duoc goi truc tiep trong Activity/Fragment/Adapter.
 */
public final class ExifReader {

    private static final Map<String, String> TAG_LABELS = buildLabels();

    private ExifReader() { }

    /** Doc toan bo tag EXIF co gia tri, tra ve danh sach da gan nhan de nguoi de doc. */
    public static List<ExifEntry> read(File imageFile) {
        List<ExifEntry> result = new ArrayList<>();
        try {
            ExifInterface exif = new ExifInterface(imageFile.getAbsolutePath());
            for (Map.Entry<String, String> tag : TAG_LABELS.entrySet()) {
                String value = exif.getAttribute(tag.getKey());
                if (value != null && !value.trim().isEmpty()) {
                    result.add(new ExifEntry(tag.getValue(), value));
                }
            }
            appendGpsIfPresent(exif, result);
        } catch (IOException e) {
            result.add(new ExifEntry("Loi", "Khong doc duoc metadata: " + e.getMessage()));
        }
        return result;
    }

    private static void appendGpsIfPresent(ExifInterface exif, List<ExifEntry> result) {
        double[] latLong = exif.getLatLong();
        if (latLong != null) {
            result.add(new ExifEntry("Vi do", String.valueOf(latLong[0])));
            result.add(new ExifEntry("Kinh do", String.valueOf(latLong[1])));
        }
    }

    private static Map<String, String> buildLabels() {
        Map<String, String> map = new LinkedHashMap<>();
        map.put(ExifInterface.TAG_DATETIME, "Ngay chup");
        map.put(ExifInterface.TAG_MAKE, "Hang may");
        map.put(ExifInterface.TAG_MODEL, "Model may");
        map.put(ExifInterface.TAG_IMAGE_WIDTH, "Chieu rong (px)");
        map.put(ExifInterface.TAG_IMAGE_LENGTH, "Chieu cao (px)");
        map.put(ExifInterface.TAG_ORIENTATION, "Huong xoay");
        map.put(ExifInterface.TAG_F_NUMBER, "Khau do (f)");
        map.put(ExifInterface.TAG_EXPOSURE_TIME, "Toc do mang trap");
        map.put(ExifInterface.TAG_ISO_SPEED_RATINGS, "ISO");
        map.put(ExifInterface.TAG_FOCAL_LENGTH, "Tieu cu");
        map.put(ExifInterface.TAG_WHITE_BALANCE, "Can bang trang");
        map.put(ExifInterface.TAG_FLASH, "Flash");
        return map;
    }
}
