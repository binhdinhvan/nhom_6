package com.example.myfile.feature.viewer.text;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

/**
 * Doc noi dung file text (gioi han kich thuoc de tranh OOM khi mo nham
 * file lon). Chi duoc goi tu ViewModel, khong tu Activity/Fragment.
 */
public final class TextFileReader {

    /** Gioi han 2MB — du cho hau het file log/config, tranh treo UI. */
    private static final long MAX_BYTES = 2L * 1024 * 1024;

    private TextFileReader() { }

    public static String read(File file) throws IOException {
        StringBuilder sb = new StringBuilder();
        boolean truncated = false;
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (sb.length() > MAX_BYTES) {
                    truncated = true;
                    break;
                }
                sb.append(line).append('\n');
            }
        }
        if (truncated) {
            sb.append("\n\n--- (Da cat bot, file qua lon de xem toan bo) ---");
        }
        return sb.toString();
    }
}
