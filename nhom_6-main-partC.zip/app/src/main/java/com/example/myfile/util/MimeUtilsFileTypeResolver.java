package com.example.myfile.util;

import com.example.myfile.core.model.FileType;
import com.example.myfile.core.repository.FileTypeResolver;

import javax.inject.Inject;
import javax.inject.Singleton;

/**
 * [C] Ban "that" cua FileTypeResolver, thay the DefaultFileTypeResolver (tam).
 *
 * Chi la lop bao (adapter) quanh {@link MimeUtils} de LocalFileRepositoryImpl
 * (khong doi) tiep tuc goi qua interface FileTypeResolver.
 *
 * Kich hoat bang cach doi @Binds trong core/di/RepositoryModule:
 *   bindTypeResolver(MimeUtilsFileTypeResolver impl) thay vi DefaultFileTypeResolver.
 */
@Singleton
public class MimeUtilsFileTypeResolver implements FileTypeResolver {

    @Inject
    public MimeUtilsFileTypeResolver() { }

    @Override
    public FileType resolve(String fileName, boolean isDirectory) {
        return MimeUtils.typeOf(fileName, isDirectory);
    }

    @Override
    public String mimeTypeOf(String fileName) {
        return MimeUtils.mimeTypeOf(fileName);
    }
}
