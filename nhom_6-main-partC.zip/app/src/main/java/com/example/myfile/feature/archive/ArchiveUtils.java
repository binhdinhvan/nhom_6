package com.example.myfile.feature.archive;

import androidx.annotation.NonNull;

import java.io.File;
import java.io.IOException;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * [C] Tien ich rieng cho feature/archive: dem so entry trong file .zip,
 * tinh tong dung luong sau giai nen, va sinh ten file zip khong trung.
 */
public final class ArchiveUtils {

    private ArchiveUtils() { }

    /** Dem so entry (ca file lan thu muc) trong 1 file .zip. */
    public static int countEntries(@NonNull File zipFile) throws IOException {
        try (ZipFile zf = new ZipFile(zipFile)) {
            return zf.size();
        }
    }

    /** Tong dung luong SAU KHI giai nen (uncompressed), don vi byte. -1 neu khong doc duoc entry nao. */
    public static long totalUncompressedSize(@NonNull File zipFile) throws IOException {
        long total = 0;
        try (ZipFile zf = new ZipFile(zipFile)) {
            Enumeration<? extends ZipEntry> entries = zf.entries();
            while (entries.hasMoreElements()) {
                ZipEntry entry = entries.nextElement();
                long size = entry.getSize();
                if (size > 0) total += size;
            }
        }
        return total;
    }

    /** Sinh ten file .zip khong trung trong thu muc dich: "abc.zip" -> "abc (1).zip". */
    @NonNull
    public static String uniqueZipName(@NonNull File destDir, @NonNull String desiredBaseName) {
        String name = desiredBaseName.toLowerCase().endsWith(".zip")
                ? desiredBaseName : desiredBaseName + ".zip";
        File target = new File(destDir, name);
        if (!target.exists()) return name;

        String base = name.substring(0, name.length() - 4); // bo ".zip"
        int index = 1;
        String candidate;
        do {
            candidate = base + " (" + index + ").zip";
            index++;
        } while (new File(destDir, candidate).exists() && index < 1000);
        return candidate;
    }
}
