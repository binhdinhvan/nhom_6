package com.example.myfile.feature.viewer.exif;

import com.example.myfile.core.AppExecutors;
import com.example.myfile.core.base.BaseViewModel;
import com.example.myfile.core.model.FileItem;

import java.util.List;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

/**
 * Cau noi giua ExifViewerActivity (UI) va ExifReader (doc file EXIF).
 * Tuan thu quy tac "UI khong duoc goi FileItem.toFile()/java.io.File truc tiep":
 * viec do dua het vao day, chay tren background thread cua AppExecutors.
 */
@HiltViewModel
public class ExifViewModel extends BaseViewModel<List<ExifEntry>> {

    @Inject
    public ExifViewModel(AppExecutors executors) {
        super(executors);
    }

    public void load(FileItem imageItem) {
        setLoading();
        runOnDisk(() -> {
            List<ExifEntry> entries = ExifReader.read(imageItem.toFile());
            if (entries.isEmpty()) {
                setEmpty();
            } else {
                setSuccess(entries);
            }
        });
    }
}
