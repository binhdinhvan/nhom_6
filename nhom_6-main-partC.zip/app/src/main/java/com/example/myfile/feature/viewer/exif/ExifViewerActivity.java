package com.example.myfile.feature.viewer.exif;

import android.content.Context;
import android.content.Intent;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.myfile.core.base.BaseActivity;
import com.example.myfile.core.model.FileItem;
import com.example.myfile.core.model.UiState;
import com.example.myfile.databinding.ActivityExifViewerBinding;

import dagger.hilt.android.AndroidEntryPoint;

/** [C] Xem metadata EXIF cua 1 anh (may chup, thoi gian, GPS, khau do...). */
@AndroidEntryPoint
public class ExifViewerActivity extends BaseActivity<ActivityExifViewerBinding> {

    private static final String EXTRA_FILE_ITEM = "extra_file_item";

    private ExifViewModel viewModel;
    private ExifAdapter adapter;

    public static void start(@NonNull Context context, @NonNull FileItem imageItem) {
        Intent intent = new Intent(context, ExifViewerActivity.class);
        intent.putExtra(EXTRA_FILE_ITEM, imageItem);
        context.startActivity(intent);
    }

    @Override
    protected ActivityExifViewerBinding inflateBinding() {
        return ActivityExifViewerBinding.inflate(getLayoutInflater());
    }

    @Override
    protected void initViews() {
        setSupportActionBar(binding.toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        binding.toolbar.setNavigationOnClickListener(v -> finish());

        adapter = new ExifAdapter();
        binding.recyclerExif.setLayoutManager(new LinearLayoutManager(this));
        binding.recyclerExif.setAdapter(adapter);

        viewModel = new ViewModelProvider(this).get(ExifViewModel.class);
    }

    @Override
    protected void observeData() {
        viewModel.getUiState().observe(this, this::onUiState);

        FileItem item = getIntent().getParcelableExtra(EXTRA_FILE_ITEM);
        if (item == null) {
            finish();
            return;
        }
        if (getSupportActionBar() != null) getSupportActionBar().setTitle(item.getName());
        viewModel.load(item);
    }

    private void onUiState(UiState<?> state) {
        switch (state.getStatus()) {
            case LOADING:
                binding.progressBar.setVisibility(View.VISIBLE);
                binding.textEmpty.setVisibility(View.GONE);
                binding.recyclerExif.setVisibility(View.GONE);
                break;
            case SUCCESS:
                binding.progressBar.setVisibility(View.GONE);
                binding.textEmpty.setVisibility(View.GONE);
                binding.recyclerExif.setVisibility(View.VISIBLE);
                //noinspection unchecked
                adapter.submitList((java.util.List<ExifEntry>) state.getData());
                break;
            case EMPTY:
                binding.progressBar.setVisibility(View.GONE);
                binding.recyclerExif.setVisibility(View.GONE);
                binding.textEmpty.setVisibility(View.VISIBLE);
                binding.textEmpty.setText(com.example.myfile.R.string.exif_empty);
                break;
            case ERROR:
                binding.progressBar.setVisibility(View.GONE);
                binding.recyclerExif.setVisibility(View.GONE);
                binding.textEmpty.setVisibility(View.VISIBLE);
                binding.textEmpty.setText(state.getMessage());
                break;
        }
    }
}
