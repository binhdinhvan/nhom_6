package com.example.myfile.feature.viewer.video;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModelProvider;

import com.example.myfile.R;
import com.example.myfile.core.base.BaseActivity;
import com.example.myfile.core.model.FileItem;
import com.example.myfile.core.model.UiState;
import com.example.myfile.databinding.ActivityVideoPlayerBinding;
import com.example.myfile.util.FileUtils;
import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.MediaItem;

import java.util.List;

import dagger.hilt.android.AndroidEntryPoint;

/**
 * [C] Phat video bang ExoPlayer (SimpleExoPlayer da duoc thay the boi
 * ExoPlayer.Builder tu 2.15+, van goi la "SimpleExoPlayer" trong yeu cau).
 *
 * Nut Next/Prev doc du lieu tu PlaylistHelper, danh sach "anh chi em" duoc
 * nap qua VideoPlayerViewModel (khong tu mo java.io.File trong Activity).
 */
@AndroidEntryPoint
public class VideoPlayerActivity extends BaseActivity<ActivityVideoPlayerBinding> {

    private static final String EXTRA_FILE_ITEM = "extra_file_item";

    private VideoPlayerViewModel viewModel;
    private ExoPlayer player;
    private PlaylistHelper playlistHelper;
    private FileItem startItem;

    public static void start(@NonNull Context context, @NonNull FileItem item) {
        Intent intent = new Intent(context, VideoPlayerActivity.class);
        intent.putExtra(EXTRA_FILE_ITEM, item);
        context.startActivity(intent);
    }

    @Override
    protected ActivityVideoPlayerBinding inflateBinding() {
        return ActivityVideoPlayerBinding.inflate(getLayoutInflater());
    }

    @Override
    protected void initViews() {
        setSupportActionBar(binding.toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        binding.toolbar.setNavigationOnClickListener(v -> finish());

        startItem = getIntent().getParcelableExtra(EXTRA_FILE_ITEM);
        if (startItem == null) {
            finish();
            return;
        }
        getSupportActionBar().setTitle(startItem.getName());

        player = new ExoPlayer.Builder(this).build();
        binding.playerView.setPlayer(player);

        binding.buttonNext.setOnClickListener(v -> playNext());
        binding.buttonPrevious.setOnClickListener(v -> playPrevious());

        viewModel = new ViewModelProvider(this).get(VideoPlayerViewModel.class);
    }

    @Override
    protected void observeData() {
        viewModel.getUiState().observe(this, this::onUiState);
        String parent = startItem != null ? startItem.getParentPath() : null;
        viewModel.loadSiblings(parent);
    }

    private void onUiState(UiState<List<FileItem>> state) {
        if (state.getStatus() != UiState.Status.SUCCESS || state.getData() == null) {
            // Khong nap duoc danh sach cung thu muc -> van phat rieng file da chon
            playlistHelper = new PlaylistHelper(java.util.Collections.singletonList(startItem), startItem);
        } else {
            playlistHelper = new PlaylistHelper(state.getData(), startItem);
        }
        updateNavButtons();
        playCurrent();
    }

    private void playCurrent() {
        FileItem item = playlistHelper.current();
        getSupportActionBar().setTitle(item.getName());
        Uri uri = FileUtils.contentUriFor(this, item.toFile());
        player.setMediaItem(MediaItem.fromUri(uri));
        player.prepare();
        player.setPlayWhenReady(true);
        updateNavButtons();
    }

    private void playNext() {
        if (playlistHelper.next() != null) playCurrent();
    }

    private void playPrevious() {
        if (playlistHelper.previous() != null) playCurrent();
    }

    private void updateNavButtons() {
        binding.buttonNext.setVisibility(playlistHelper.hasNext() ? View.VISIBLE : View.GONE);
        binding.buttonPrevious.setVisibility(playlistHelper.hasPrevious() ? View.VISIBLE : View.GONE);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (player != null) player.setPlayWhenReady(false);
    }

    @Override
    protected void onDestroy() {
        if (player != null) {
            player.release();
            player = null;
        }
        super.onDestroy();
    }
}
