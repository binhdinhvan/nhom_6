package com.example.myfile.feature.archive;

import androidx.annotation.NonNull;

import com.example.myfile.core.model.FileItem;
import com.example.myfile.core.operation.AbstractFileOperation;
import com.example.myfile.core.operation.OperationException;
import com.example.myfile.util.MimeUtils;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Giai nen 1 file .zip ra thu muc dich (mac dinh: 1 thu muc con cung ten
 * file zip, de khong lam ron thu muc hien tai).
 *
 * Ke thua AbstractFileOperation<List<FileItem>>: tra ve danh sach cac
 * muc o cap cao nhat vua duoc giai nen (de UI hien thi/refresh).
 */
public class UnzipOperation extends AbstractFileOperation<List<FileItem>> {

    private final FileItem zipFileItem;
    private final String destDirPath;

    /**
     * @param zipFileItem file .zip nguon
     * @param destDirPath thu muc se chua noi dung giai nen (Caller quyet dinh
     *                     co tao thu muc con cung ten zip hay khong)
     */
    public UnzipOperation(@NonNull FileItem zipFileItem, @NonNull String destDirPath) {
        this.zipFileItem = zipFileItem;
        this.destDirPath = destDirPath;
    }

    @Override
    protected List<FileItem> doExecute() throws Exception {
        File zipFile = zipFileItem.toFile();
        if (!zipFile.exists()) {
            throw new OperationException("File zip khong ton tai");
        }

        File destDir = new File(destDirPath);
        if (!destDir.exists() && !destDir.mkdirs()) {
            throw new OperationException("Khong tao duoc thu muc dich");
        }

        int totalEntries = safeCountEntries(zipFile);
        int[] done = {0};
        Set<String> topLevelNames = new HashSet<>();

        try (ZipInputStream zis = new ZipInputStream(new java.io.FileInputStream(zipFile))) {
            ZipEntry entry;
            byte[] buffer = new byte[8 * 1024];

            while ((entry = zis.getNextEntry()) != null) {
                throwIfCancelled();

                File outFile = safeTargetFile(destDir, entry.getName());
                topLevelNames.add(firstSegment(entry.getName()));

                if (entry.isDirectory()) {
                    if (!outFile.exists() && !outFile.mkdirs()) {
                        throw new OperationException("Khong tao duoc thu muc " + entry.getName());
                    }
                } else {
                    File parent = outFile.getParentFile();
                    if (parent != null && !parent.exists() && !parent.mkdirs()) {
                        throw new OperationException("Khong tao duoc thu muc cha cho " + entry.getName());
                    }
                    publishProgress(done[0], totalEntries, entry.getName());
                    try (BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(outFile))) {
                        int read;
                        while ((read = zis.read(buffer)) != -1) {
                            throwIfCancelled();
                            out.write(buffer, 0, read);
                        }
                    }
                    done[0]++;
                    publishProgress(done[0], totalEntries, entry.getName());
                }
                zis.closeEntry();
            }
        } catch (IOException e) {
            throw new OperationException("Giai nen that bai: " + e.getMessage(), e);
        }

        return topLevelResult(destDir, topLevelNames);
    }

    /** Chan Zip Slip: ngan entry co duong dan thoat khoi thu muc dich (vd "../../etc/passwd"). */
    private File safeTargetFile(File destDir, String entryName) throws OperationException {
        File target = new File(destDir, entryName);
        String destPath = destDir.getAbsolutePath();
        String targetPath = target.getAbsolutePath();
        if (!targetPath.startsWith(destPath + File.separator) && !targetPath.equals(destPath)) {
            throw new OperationException("File zip chua duong dan khong hop le: " + entryName);
        }
        return target;
    }

    private String firstSegment(String entryName) {
        int slash = entryName.indexOf('/');
        return slash > 0 ? entryName.substring(0, slash) : entryName;
    }

    private List<FileItem> topLevelResult(File destDir, Set<String> topLevelNames) {
        List<FileItem> result = new ArrayList<>();
        for (String name : topLevelNames) {
            File f = new File(destDir, name);
            if (f.exists()) result.add(toFileItem(f));
        }
        return result;
    }

    private int safeCountEntries(File zipFile) {
        try {
            return Math.max(ArchiveUtils.countEntries(zipFile), 1);
        } catch (IOException e) {
            return 1; // khong biet tong -> UI hien thi progress khong xac dinh
        }
    }

    private FileItem toFileItem(File f) {
        boolean isDir = f.isDirectory();
        return new FileItem(
                f.getAbsolutePath(),
                f.getName(),
                isDir ? 0 : f.length(),
                f.lastModified(),
                isDir,
                f.isHidden(),
                MimeUtils.typeOf(f.getName(), isDir),
                isDir ? null : MimeUtils.mimeTypeOf(f.getName())
        );
    }

    @Override
    public String getDisplayName() {
        return "Dang giai nen " + zipFileItem.getName();
    }
}
