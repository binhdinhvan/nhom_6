package com.example.myfile.util;

import java.util.Locale;

/** [C] Util tinh: bytes -> chuoi de doc, vd "1.2 MB". */
public final class SizeFormatter {

    private static final String[] UNITS = {"B", "KB", "MB", "GB", "TB"};

    private SizeFormatter() { }

    public static String format(long bytes) {
        if (bytes < 0) bytes = 0;
        if (bytes < 1024) return bytes + " B";

        double value = bytes;
        int unitIndex = 0;
        while (value >= 1024 && unitIndex < UNITS.length - 1) {
            value /= 1024;
            unitIndex++;
        }
        return String.format(Locale.getDefault(), "%.1f %s", value, UNITS[unitIndex]);
    }
}
