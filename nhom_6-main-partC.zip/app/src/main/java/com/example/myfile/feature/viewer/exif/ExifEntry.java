package com.example.myfile.feature.viewer.exif;

/** 1 dong metadata EXIF hien thi trong RecyclerView cua ExifViewerActivity. */
public final class ExifEntry {

    private final String label;
    private final String value;

    public ExifEntry(String label, String value) {
        this.label = label;
        this.value = value;
    }

    public String getLabel() { return label; }
    public String getValue() { return value; }
}
