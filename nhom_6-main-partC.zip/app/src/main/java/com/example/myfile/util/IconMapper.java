package com.example.myfile.util;

import androidx.annotation.DrawableRes;
import androidx.annotation.NonNull;

import com.example.myfile.R;
import com.example.myfile.core.model.FileItem;
import com.example.myfile.core.model.FileType;

/**
 * [C] Util tinh: anh xa FileType -> icon hien thi (drawable res id).
 * Dung trong FileAdapter (danh sach), ViewerFactory fallback, PropertiesDialog...
 */
public final class IconMapper {

    private IconMapper() { /* static-only */ }

    @DrawableRes
    public static int iconFor(@NonNull FileType type) {
        switch (type) {
            case FOLDER:   return R.drawable.ic_type_folder;
            case IMAGE:    return R.drawable.ic_type_image;
            case VIDEO:    return R.drawable.ic_type_video;
            case AUDIO:    return R.drawable.ic_type_audio;
            case ARCHIVE:  return R.drawable.ic_type_archive;
            case DOCUMENT: return R.drawable.ic_type_doc;
            case APK:      return R.drawable.ic_type_apk;
            case TEXT:     return R.drawable.ic_type_text;
            case OTHER:
            default:       return R.drawable.ic_type_other;
        }
    }

    /** Tien ich: lay icon truc tiep tu FileItem (co xet ca isDirectory). */
    @DrawableRes
    public static int iconFor(@NonNull FileItem item) {
        if (item.isDirectory()) return R.drawable.ic_type_folder;
        return iconFor(item.getType());
    }
}
