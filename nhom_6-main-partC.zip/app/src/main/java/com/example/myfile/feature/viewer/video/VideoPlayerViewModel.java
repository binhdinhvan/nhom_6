package com.example.myfile.feature.viewer.video;

import com.example.myfile.core.AppExecutors;
import com.example.myfile.core.base.BaseViewModel;
import com.example.myfile.core.model.FileItem;
import com.example.myfile.core.model.OperationResult;
import com.example.myfile.core.repository.FileRepository;

import java.util.List;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

/**
 * Tuan thu quy tac "View khong goi thang FileRepository": VideoPlayerActivity
 * chi doc UiState tu day, khong tu mo java.io.File.
 */
@HiltViewModel
public class VideoPlayerViewModel extends BaseViewModel<List<FileItem>> {

    private final FileRepository repository;

    @Inject
    public VideoPlayerViewModel(AppExecutors executors, FileRepository repository) {
        super(executors);
        this.repository = repository;
    }

    /** Nap danh sach file cung thu muc voi video dang xem, de dung xay PlaylistHelper. */
    public void loadSiblings(String parentDirPath) {
        if (parentDirPath == null) {
            setError("Khong xac dinh duoc thu muc chua video");
            return;
        }
        setLoading();
        runOnDisk(() -> {
            OperationResult<List<FileItem>> r = repository.listFiles(parentDirPath, false);
            if (!r.isSuccess()) {
                setError(r.getErrorMessage());
            } else {
                setSuccess(r.getData());
            }
        });
    }
}
