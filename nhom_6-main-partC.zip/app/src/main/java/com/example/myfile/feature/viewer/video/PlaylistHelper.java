package com.example.myfile.feature.viewer.video;

import androidx.annotation.Nullable;

import com.example.myfile.core.model.FileItem;
import com.example.myfile.util.MimeUtils;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Tach logic "playlist" ra khoi Activity: loc cac file VIDEO trong cung
 * thu muc, sap xep theo ten, va tra ve video ke tiep/truoc do.
 *
 * VideoPlayerActivity chi goi PlaylistHelper.next()/previous(), khong tu
 * lam viec voi List<FileItem> tho.
 */
public class PlaylistHelper {

    private final List<FileItem> playlist;
    private int currentIndex;

    public PlaylistHelper(List<FileItem> allFilesInFolder, FileItem current) {
        this.playlist = new ArrayList<>();
        for (FileItem f : allFilesInFolder) {
            if (!f.isDirectory() && MimeUtils.isVideo(f.getName())) {
                playlist.add(f);
            }
        }
        java.util.Collections.sort(playlist, Comparator.comparing(FileItem::getName, String.CASE_INSENSITIVE_ORDER));

        this.currentIndex = indexOf(current);
        if (currentIndex < 0) {
            // current khong nam trong danh sach (vd mo truc tiep 1 file le) -> chen vao dau
            playlist.add(0, current);
            currentIndex = 0;
        }
    }

    public FileItem current() {
        return playlist.get(currentIndex);
    }

    public boolean hasNext() {
        return currentIndex < playlist.size() - 1;
    }

    public boolean hasPrevious() {
        return currentIndex > 0;
    }

    @Nullable
    public FileItem next() {
        if (!hasNext()) return null;
        currentIndex++;
        return current();
    }

    @Nullable
    public FileItem previous() {
        if (!hasPrevious()) return null;
        currentIndex--;
        return current();
    }

    public int size() {
        return playlist.size();
    }

    private int indexOf(FileItem target) {
        for (int i = 0; i < playlist.size(); i++) {
            if (playlist.get(i).getPath().equals(target.getPath())) return i;
        }
        return -1;
    }
}
