package com.example.myfile.feature.viewer.image;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.myfile.core.base.FileItemDiffCallback;
import com.example.myfile.core.base.BaseAdapter;
import com.example.myfile.core.model.FileItem;
import com.example.myfile.databinding.ItemImagePageBinding;

/**
 * Adapter cho ViewPager2 cua ImageViewerActivity.
 * Moi trang la 1 anh, PhotoView tu ho tro pinch-to-zoom / double-tap zoom.
 */
public class ImagePagerAdapter extends BaseAdapter<FileItem, ImagePagerAdapter.PageViewHolder> {

    public ImagePagerAdapter() {
        super(new FileItemDiffCallback());
    }

    @NonNull
    @Override
    public PageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemImagePageBinding binding = ItemImagePageBinding.inflate(
                LayoutInflater.from(parent.getContext()), parent, false);
        return new PageViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull PageViewHolder holder, int position) {
        FileItem item = getItem(position);
        Glide.with(holder.binding.photoView)
                .load(item.toFile())
                .placeholder(com.example.myfile.R.drawable.ic_type_image)
                .error(com.example.myfile.R.drawable.ic_type_image)
                .into(holder.binding.photoView);
    }

    static class PageViewHolder extends RecyclerView.ViewHolder {
        final ItemImagePageBinding binding;

        PageViewHolder(ItemImagePageBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}
