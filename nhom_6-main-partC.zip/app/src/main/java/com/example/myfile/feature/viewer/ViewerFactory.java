package com.example.myfile.feature.viewer;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.myfile.core.model.FileItem;
import com.example.myfile.feature.viewer.image.ImageViewerActivity;
import com.example.myfile.feature.viewer.text.TextViewerActivity;
import com.example.myfile.feature.viewer.video.VideoPlayerActivity;
import com.example.myfile.util.FileUtils;
import com.example.myfile.util.MimeUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * ⚑ FACTORY PATTERN — diem vao duy nhat de "mo" mot file.
 *
 * FileListFragment (A/B) chi can goi ViewerFactory.open(context, item, siblings)
 * khi nguoi dung tap vao 1 file; khong can biet Activity nao se duoc mo.
 *
 * Quy tac dinh tuyen theo FileType (suy ra tu MIME/extension boi MimeUtils):
 *   IMAGE   -> ImageViewerActivity (Glide + PhotoView + ViewPager2, vuot ca folder)
 *   VIDEO   -> VideoPlayerActivity (ExoPlayer, playlist ke tiep/truoc trong folder)
 *   TEXT    -> TextViewerActivity
 *   ARCHIVE -> khong tu mo o day; UI (B) hoi "Giai nen?" roi goi UnzipOperation
 *   con lai -> giao he thong xu ly bang Intent.ACTION_VIEW qua FileProvider
 */
public final class ViewerFactory {

    private ViewerFactory() { }

    /** Mo 1 file, tu dong gom danh sach "anh chi em" cung thu muc de vuot trai/phai. */
    public static void open(@NonNull Context context, @NonNull FileItem item) {
        open(context, item, buildSiblingList(item));
    }

    /**
     * @param siblings danh sach file cung loai trong cung thu muc (de ImageViewer/VideoPlayer
     *                 cho phep vuot/next-prev). Neu null hoac rong, chi mo minh item.
     */
    public static void open(@NonNull Context context, @NonNull FileItem item,
                            @Nullable List<FileItem> siblings) {
        if (item.isDirectory()) {
            return; // duyet thu muc thuoc ve NavigationManager (A), khong phai viewer
        }

        switch (item.getType()) {
            case IMAGE:
                ImageViewerActivity.start(context, item, nonNull(siblings));
                return;
            case VIDEO:
                VideoPlayerActivity.start(context, item);
                return;
            case TEXT:
                TextViewerActivity.start(context, item);
                return;
            case ARCHIVE:
                // Y do mo (khong phai giai nen) -> van cho xem qua trinh xem he thong neu co,
                // giai nen thuc su do feature/archive (ArchiveViewModel) dam nhiem tu action rieng.
                openWithSystemViewer(context, item);
                return;
            default:
                openWithSystemViewer(context, item);
        }
    }

    /** Nhung loai C khong tu ve UI (APK, DOC, OTHER...) -> nho app ngoai xu ly. */
    private static void openWithSystemViewer(@NonNull Context context, @NonNull FileItem item) {
        try {
            File file = item.toFile();
            android.net.Uri uri = FileUtils.contentUriFor(context, file);
            String mime = MimeUtils.mimeTypeOf(item.getName());

            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(uri, mime);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(context, "Khong co ung dung phu hop de mo file nay", Toast.LENGTH_SHORT).show();
        }
    }

    private static List<FileItem> buildSiblingList(FileItem item) {
        // Mac dinh chi minh item; UI (Fragment) nen truyen danh sach thuc te
        // (list dang hien thi trong RecyclerView) qua overload co siblings.
        List<FileItem> single = new ArrayList<>(1);
        single.add(item);
        return single;
    }

    private static List<FileItem> nonNull(@Nullable List<FileItem> list) {
        return list != null ? list : new ArrayList<>();
    }
}
