package com.example.myfile.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** [C] Util tinh: timestamp (millis) -> chuoi ngay/gio hien thi. */
public final class DateFormatter {

    private static final String PATTERN = "dd/MM/yyyy HH:mm";

    private DateFormatter() { }

    public static String format(long timestampMillis) {
        SimpleDateFormat sdf = new SimpleDateFormat(PATTERN, Locale.getDefault());
        return sdf.format(new Date(timestampMillis));
    }
}
