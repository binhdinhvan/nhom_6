package com.example.myfile.feature.archive;

import com.example.myfile.core.AppExecutors;
import com.example.myfile.core.base.BaseViewModel;
import com.example.myfile.core.event.FileChangedEvent;
import com.example.myfile.core.event.OperationCompleteEvent;
import com.example.myfile.core.event.OperationProgressEvent;
import com.example.myfile.core.model.FileItem;
import com.example.myfile.core.model.OperationResult;
import com.example.myfile.core.operation.FileOperation;

import org.greenrobot.eventbus.EventBus;

import java.util.Collections;
import java.util.List;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

/**
 * ViewModel cho chuc nang Nen/Giai nen. Chay ZipOperation / UnzipOperation
 * tren background thread (quy tac chung: khong tu tao Thread), bao tien do
 * qua EventBus de ProgressDialogFragment (B) subscribe, va phat
 * FileChangedEvent sau khi xong de danh sach tu refresh (quy tac 4 cua core).
 */
@HiltViewModel
public class ArchiveViewModel extends BaseViewModel<List<FileItem>> {

    @Inject
    public ArchiveViewModel(AppExecutors executors) {
        super(executors);
    }

    /** Nen danh sach FileItem thanh 1 file .zip trong destDirPath. */
    public void zip(List<FileItem> sources, String destDirPath, String zipFileName) {
        setLoading();
        runOnDisk(() -> {
            ZipOperation operation = new ZipOperation(sources, destDirPath, zipFileName);
            operation.setProgressListener((current, total, currentItem) ->
                    postProgress(operation, current, total, currentItem));

            OperationResult<FileItem> result = operation.execute();
            postComplete(operation, result.isSuccess(), result.isCancelled(), result.getErrorMessage());

            if (result.isSuccess()) {
                EventBus.getDefault().post(
                        new FileChangedEvent(destDirPath, FileChangedEvent.ChangeType.CREATED));
                setSuccess(Collections.singletonList(result.getData()));
            } else if (result.isCancelled()) {
                setError("Da huy thao tac nen");
            } else {
                setError(result.getErrorMessage());
            }
        });
    }

    /** Giai nen zipItem ra destDirPath. */
    public void unzip(FileItem zipItem, String destDirPath) {
        setLoading();
        runOnDisk(() -> {
            UnzipOperation operation = new UnzipOperation(zipItem, destDirPath);
            operation.setProgressListener((current, total, currentItem) ->
                    postProgress(operation, current, total, currentItem));

            OperationResult<List<FileItem>> result = operation.execute();
            postComplete(operation, result.isSuccess(), result.isCancelled(), result.getErrorMessage());

            if (result.isSuccess()) {
                EventBus.getDefault().post(
                        new FileChangedEvent(destDirPath, FileChangedEvent.ChangeType.CREATED));
                setSuccess(result.getData());
            } else if (result.isCancelled()) {
                setError("Da huy thao tac giai nen");
            } else {
                setError(result.getErrorMessage());
            }
        });
    }

    private void postProgress(FileOperation<?> op, long current, long total, String currentItem) {
        EventBus.getDefault().post(new OperationProgressEvent(
                op.getOperationId(), op.getDisplayName(), current, total, currentItem));
    }

    private void postComplete(FileOperation<?> op, boolean success, boolean cancelled, String message) {
        EventBus.getDefault().post(new OperationCompleteEvent(
                op.getOperationId(), op.getDisplayName(), success, cancelled, message));
    }
}
