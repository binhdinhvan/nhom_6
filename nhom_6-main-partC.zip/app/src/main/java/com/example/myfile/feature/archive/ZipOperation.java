package com.example.myfile.feature.archive;

import androidx.annotation.NonNull;

import com.example.myfile.core.model.FileItem;
import com.example.myfile.core.operation.AbstractFileOperation;
import com.example.myfile.core.operation.OperationException;
import com.example.myfile.util.FileUtils;
import com.example.myfile.util.MimeUtils;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Nen 1 hoac nhieu FileItem (file/folder) thanh 1 file .zip trong thu muc dich.
 *
 * Ke thua AbstractFileOperation<FileItem> theo Template Method Pattern cua core:
 * chi can cai dat doExecute(), khung try/catch/cancel/finish da co san.
 *
 * Progress bao theo SO FILE da nen (khong phai byte), vi tinh tong byte truoc
 * khi nen tон nhieu thoi gian voi thu muc lon.
 */
public class ZipOperation extends AbstractFileOperation<FileItem> {

    private final List<FileItem> sources;
    private final String destDirPath;
    private final String zipFileName;

    /**
     * @param sources     danh sach file/folder can nen (>= 1)
     * @param destDirPath thu muc se chua file .zip ket qua
     * @param zipFileName ten file zip mong muon (se tu dong khong trung ten)
     */
    public ZipOperation(@NonNull List<FileItem> sources,
                        @NonNull String destDirPath,
                        @NonNull String zipFileName) {
        this.sources = sources;
        this.destDirPath = destDirPath;
        this.zipFileName = zipFileName;
    }

    @Override
    protected FileItem doExecute() throws Exception {
        if (sources.isEmpty()) {
            throw new OperationException("Khong co file nao duoc chon de nen");
        }

        File destDir = new File(destDirPath);
        if (!destDir.exists() && !destDir.mkdirs()) {
            throw new OperationException("Khong tao duoc thu muc dich");
        }
        String uniqueName = ArchiveUtils.uniqueZipName(destDir, zipFileName);
        File zipFile = new File(destDir, uniqueName);

        int totalFiles = countTotalFiles();
        int[] done = {0};

        try (ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(zipFile))) {
            for (FileItem source : sources) {
                throwIfCancelled();
                File src = source.toFile();
                addToZip(zos, src, src.getName(), totalFiles, done);
            }
        } catch (IOException e) {
            //noinspection ResultOfMethodCallIgnored
            zipFile.delete();
            throw new OperationException("Nen that bai: " + e.getMessage(), e);
        }

        if (isCancelled()) {
            //noinspection ResultOfMethodCallIgnored
            zipFile.delete();
            throw new OperationException("Da huy thao tac");
        }

        return toFileItem(zipFile);
    }

    private void addToZip(ZipOutputStream zos, File file, String entryPath,
                          int totalFiles, int[] done) throws IOException, OperationException {
        throwIfCancelled();

        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children == null || children.length == 0) {
                // Thu muc rong -> van ghi entry de giu cau truc khi giai nen lai
                zos.putNextEntry(new ZipEntry(entryPath + "/"));
                zos.closeEntry();
                return;
            }
            for (File child : children) {
                addToZip(zos, child, entryPath + "/" + child.getName(), totalFiles, done);
            }
            return;
        }

        publishProgress(done[0], totalFiles, file.getName());
        try (BufferedInputStream in = new BufferedInputStream(new FileInputStream(file))) {
            zos.putNextEntry(new ZipEntry(entryPath));
            FileUtils.copyStream(in, zos);
            zos.closeEntry();
        }
        done[0]++;
        publishProgress(done[0], totalFiles, file.getName());
    }

    private int countTotalFiles() {
        int total = 0;
        for (FileItem source : sources) {
            total += FileUtils.countFilesRecursive(source.toFile());
        }
        return Math.max(total, 1);
    }

    private FileItem toFileItem(File f) {
        return new FileItem(
                f.getAbsolutePath(),
                f.getName(),
                f.length(),
                f.lastModified(),
                false,
                f.isHidden(),
                MimeUtils.typeOf(f.getName(), false),
                MimeUtils.mimeTypeOf(f.getName())
        );
    }

    @Override
    public String getDisplayName() {
        return "Dang nen " + sources.size() + " muc";
    }
}
