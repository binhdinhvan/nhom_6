package com.example.myfile.feature.viewer.exif;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myfile.core.base.BaseAdapter;
import com.example.myfile.databinding.ItemExifRowBinding;

public class ExifAdapter extends BaseAdapter<ExifEntry, ExifAdapter.ExifViewHolder> {

    public ExifAdapter() {
        super(new DiffUtil.ItemCallback<ExifEntry>() {
            @Override
            public boolean areItemsTheSame(@NonNull ExifEntry oldItem, @NonNull ExifEntry newItem) {
                return oldItem.getLabel().equals(newItem.getLabel());
            }

            @Override
            public boolean areContentsTheSame(@NonNull ExifEntry oldItem, @NonNull ExifEntry newItem) {
                return oldItem.getValue().equals(newItem.getValue());
            }
        });
    }

    @NonNull
    @Override
    public ExifViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemExifRowBinding binding = ItemExifRowBinding.inflate(
                LayoutInflater.from(parent.getContext()), parent, false);
        return new ExifViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull ExifViewHolder holder, int position) {
        ExifEntry entry = getItem(position);
        holder.binding.textLabel.setText(entry.getLabel());
        holder.binding.textValue.setText(entry.getValue());
    }

    static class ExifViewHolder extends RecyclerView.ViewHolder {
        final ItemExifRowBinding binding;

        ExifViewHolder(ItemExifRowBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}
