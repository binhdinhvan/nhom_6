package com.example.myfile.util;

import android.content.Context;
import android.net.Uri;

import androidx.annotation.NonNull;
import androidx.core.content.FileProvider;

import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * [C] Util tinh dung chung: copy stream (dung trong Zip/Unzip), tinh size
 * de quy, sinh ten khong trung, va lay content:// Uri qua FileProvider
 * (can de mo Image/Video/Text bang app khac hoac chia se).
 *
 * Duoc goi tu feature/archive va feature/viewer -- KHONG duoc goi tu
 * Activity/Fragment/Adapter theo quy tac chung (chi ViewModel/Operation).
 */
public final class FileUtils {

    private static final int BUFFER_SIZE = 8 * 1024;

    private FileUtils() { }

    /** Copy toan bo InputStream sang OutputStream, tra ve so byte da copy. Khong dong stream. */
    public static long copyStream(@NonNull InputStream in, @NonNull OutputStream out) throws IOException {
        byte[] buffer = new byte[BUFFER_SIZE];
        long total = 0;
        int read;
        while ((read = in.read(buffer)) != -1) {
            out.write(buffer, 0, read);
            total += read;
        }
        out.flush();
        return total;
    }

    /** Tinh kich thuoc de quy (file thuong hoac thu muc). */
    public static long sizeOfRecursive(@NonNull File file) {
        if (file.isFile()) return file.length();
        File[] children = file.listFiles();
        if (children == null) return 0;
        long total = 0;
        for (File c : children) total += sizeOfRecursive(c);
        return total;
    }

    /** Dem so file thuong (khong tinh thu muc) ben trong, de quy. */
    public static int countFilesRecursive(@NonNull File file) {
        if (file.isFile()) return 1;
        File[] children = file.listFiles();
        if (children == null) return 0;
        int count = 0;
        for (File c : children) count += countFilesRecursive(c);
        return count;
    }

    /** Sinh ten khong trung trong thu muc dich: "abc.txt" -> "abc (1).txt". */
    @NonNull
    public static String uniqueName(@NonNull File parentDir, @NonNull String desiredName) {
        File target = new File(parentDir, desiredName);
        if (!target.exists()) return desiredName;

        String base = desiredName;
        String ext = "";
        int dot = desiredName.lastIndexOf('.');
        if (dot > 0) {
            base = desiredName.substring(0, dot);
            ext = desiredName.substring(dot);
        }
        int index = 1;
        String candidate;
        do {
            candidate = base + " (" + index + ")" + ext;
            index++;
        } while (new File(parentDir, candidate).exists() && index < 1000);
        return candidate;
    }

    /** content:// Uri qua FileProvider, dung de chia se/mo file bang app ngoai (khong loi FileUriExposed). */
    @NonNull
    public static Uri contentUriFor(@NonNull Context context, @NonNull File file) {
        String authority = context.getPackageName() + ".fileprovider";
        return FileProvider.getUriForFile(context, authority, file);
    }

    public static void closeQuietly(Closeable c) {
        if (c == null) return;
        try {
            c.close();
        } catch (IOException ignored) { }
    }
}
