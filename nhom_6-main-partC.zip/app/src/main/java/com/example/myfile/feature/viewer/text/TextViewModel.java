package com.example.myfile.feature.viewer.text;

import com.example.myfile.core.AppExecutors;
import com.example.myfile.core.base.BaseViewModel;
import com.example.myfile.core.model.FileItem;

import java.io.IOException;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class TextViewModel extends BaseViewModel<String> {

    @Inject
    public TextViewModel(AppExecutors executors) {
        super(executors);
    }

    public void load(FileItem item) {
        setLoading();
        runOnDisk(() -> {
            try {
                String content = TextFileReader.read(item.toFile());
                if (content.isEmpty()) setEmpty();
                else setSuccess(content);
            } catch (IOException e) {
                setError("Khong doc duoc file: " + e.getMessage());
            }
        });
    }
}
