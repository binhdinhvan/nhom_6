package com.example.myfile.feature.viewer.image;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.myfile.R;
import com.github.chrisbanes.photoview.PhotoView;

import java.util.List;

/** [C] Adapter cho ViewPager2 - moi trang la 1 anh, load bang Glide vao PhotoView (ho tro pinch-zoom). */
public class ImagePagerAdapter extends RecyclerView.Adapter<ImagePagerAdapter.PageViewHolder> {

    private final List<String> imagePaths;

    public ImagePagerAdapter(List<String> imagePaths) {
        this.imagePaths = imagePaths;
    }

    @NonNull
    @Override
    public PageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_image_page, parent, false);
        return new PageViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PageViewHolder holder, int position) {
        Glide.with(holder.photoView.getContext())
                .load(imagePaths.get(position))
                .into(holder.photoView);
    }

    @Override
    public int getItemCount() {
        return imagePaths.size();
    }

    static class PageViewHolder extends RecyclerView.ViewHolder {
        final PhotoView photoView;

        PageViewHolder(View itemView) {
            super(itemView);
            photoView = itemView.findViewById(R.id.photoView);
        }
    }
}
