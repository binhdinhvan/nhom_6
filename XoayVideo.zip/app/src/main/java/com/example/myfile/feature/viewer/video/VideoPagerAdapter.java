package com.example.myfile.feature.viewer.video;

import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myfile.R;
import com.google.android.exoplayer2.ui.PlayerView;

import java.util.List;

/**
 * [C] Adapter cho ViewPager2 cua VideoPlayerActivity - vuot trai/phai giua cac video
 * khac trong cung thu muc. Chi 1 ExoPlayer duy nhat duoc dung chung (video la tai
 * nguyen nang); adapter chi giu PlayerView rong cho tung trang, Activity se "gan"
 * player vao PlayerView cua trang dang hien khi nguoi dung vuot toi.
 */
public class VideoPagerAdapter extends RecyclerView.Adapter<VideoPagerAdapter.PageViewHolder> {

    private final List<String> videoPaths;
    private final SparseArray<PlayerView> boundViews = new SparseArray<>();

    public VideoPagerAdapter(List<String> videoPaths) {
        this.videoPaths = videoPaths;
    }

    @NonNull
    @Override
    public PageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_video_page, parent, false);
        return new PageViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PageViewHolder holder, int position) {
        boundViews.put(position, holder.playerView);
    }

    @Override
    public void onViewRecycled(@NonNull PageViewHolder holder) {
        int position = holder.getBindingAdapterPosition();
        if (position != RecyclerView.NO_POSITION) {
            boundViews.remove(position);
        }
    }

    @Override
    public int getItemCount() {
        return videoPaths.size();
    }

    public PlayerView playerViewAt(int position) {
        return boundViews.get(position);
    }

    static class PageViewHolder extends RecyclerView.ViewHolder {
        final PlayerView playerView;

        PageViewHolder(View itemView) {
            super(itemView);
            playerView = itemView.findViewById(R.id.playerView);
        }
    }
}
