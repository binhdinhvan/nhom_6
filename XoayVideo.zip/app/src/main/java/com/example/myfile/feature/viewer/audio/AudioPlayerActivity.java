package com.example.myfile.feature.viewer.audio;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myfile.R;
import com.example.myfile.utils.FileUtils;
import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.MediaItem;
import com.google.android.exoplayer2.Player;

import java.io.File;
import java.util.ArrayList;
import java.util.Locale;

/**
 * [C] Phat file audio (mp3, wav, m4a, aac, flac, ogg...) bang ExoPlayer.
 * Dung nut Next/Previous de chuyen bai trong cung thu muc (khong dung vuot
 * ViewPager2 nhu anh/video, vi vung thao tac SeekBar can vuot ngang tu do,
 * de tranh xung dot cu chi giua vuot-doi-bai va keo tua bai hat).
 */
public class AudioPlayerActivity extends AppCompatActivity {

    private static final String EXTRA_START_PATH = "extra_start_path";
    private static final String EXTRA_AUDIO_PATHS = "extra_audio_paths";

    private ArrayList<String> audioPaths;
    private int currentIndex = 0;
    private ExoPlayer player;

    private TextView tvTitle;
    private TextView tvCounter;
    private TextView tvElapsed;
    private TextView tvDuration;
    private SeekBar seekBar;
    private ImageButton btnPlayPause;

    private final Handler progressHandler = new Handler(Looper.getMainLooper());
    private boolean isTrackingTouch = false;

    private final Runnable progressUpdater = new Runnable() {
        @Override
        public void run() {
            updateProgress();
            progressHandler.postDelayed(this, 500);
        }
    };

    public static void start(Context context, String clickedPath, ArrayList<String> siblingAudioPaths) {
        Intent intent = new Intent(context, AudioPlayerActivity.class);
        if (siblingAudioPaths == null || siblingAudioPaths.isEmpty()) {
            siblingAudioPaths = new ArrayList<>();
            siblingAudioPaths.add(clickedPath);
        }
        intent.putExtra(EXTRA_START_PATH, clickedPath);
        intent.putStringArrayListExtra(EXTRA_AUDIO_PATHS, siblingAudioPaths);
        context.startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_audio_player);

        audioPaths = getIntent().getStringArrayListExtra(EXTRA_AUDIO_PATHS);
        if (audioPaths == null) audioPaths = new ArrayList<>();
        String startPath = getIntent().getStringExtra(EXTRA_START_PATH);
        currentIndex = Math.max(0, audioPaths.indexOf(startPath));

        tvTitle = findViewById(R.id.tvAudioTitle);
        tvCounter = findViewById(R.id.tvAudioCounter);
        tvElapsed = findViewById(R.id.tvAudioElapsed);
        tvDuration = findViewById(R.id.tvAudioDuration);
        seekBar = findViewById(R.id.seekBarAudio);
        btnPlayPause = findViewById(R.id.btnAudioPlayPause);

        findViewById(R.id.btnAudioBack).setOnClickListener(v -> finish());
        findViewById(R.id.btnAudioPrevious).setOnClickListener(v -> playAt(currentIndex - 1));
        findViewById(R.id.btnAudioNext).setOnClickListener(v -> playAt(currentIndex + 1));
        btnPlayPause.setOnClickListener(v -> togglePlayPause());

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) tvElapsed.setText(formatTime(progress));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                isTrackingTouch = true;
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                isTrackingTouch = false;
                if (player != null) player.seekTo(seekBar.getProgress());
            }
        });

        player = new ExoPlayer.Builder(this).build();
        player.addListener(new Player.Listener() {
            @Override
            public void onPlaybackStateChanged(int state) {
                if (state == Player.STATE_READY) {
                    seekBar.setMax((int) Math.max(player.getDuration(), 0));
                    tvDuration.setText(formatTime((int) Math.max(player.getDuration(), 0)));
                } else if (state == Player.STATE_ENDED) {
                    playAt(currentIndex + 1);
                }
            }

            @Override
            public void onIsPlayingChanged(boolean isPlaying) {
                btnPlayPause.setImageResource(isPlaying
                        ? android.R.drawable.ic_media_pause
                        : android.R.drawable.ic_media_play);
            }
        });

        loadTrack(currentIndex, true);
        progressHandler.post(progressUpdater);
    }

    private void togglePlayPause() {
        if (player == null) return;
        player.setPlayWhenReady(!player.getPlayWhenReady());
    }

    private void playAt(int index) {
        if (audioPaths.isEmpty()) return;
        if (index < 0 || index >= audioPaths.size()) return; // dau/cuoi danh sach - khong lam gi
        loadTrack(index, true);
    }

    private void loadTrack(int index, boolean autoPlay) {
        if (audioPaths.isEmpty()) return;
        currentIndex = index;
        String path = audioPaths.get(index);
        File file = new File(path);

        tvTitle.setText(file.getName());
        tvCounter.setText((index + 1) + " / " + audioPaths.size());
        tvElapsed.setText(formatTime(0));
        tvDuration.setText(formatTime(0));
        seekBar.setProgress(0);

        Uri uri = FileUtils.contentUriFor(this, file);
        player.setMediaItem(MediaItem.fromUri(uri));
        player.prepare();
        player.setPlayWhenReady(autoPlay);
    }

    private void updateProgress() {
        if (player == null || isTrackingTouch) return;
        long position = player.getCurrentPosition();
        seekBar.setProgress((int) Math.max(position, 0));
        tvElapsed.setText(formatTime((int) Math.max(position, 0)));
    }

    private String formatTime(int millis) {
        int totalSeconds = millis / 1000;
        int minutes = totalSeconds / 60;
        int seconds = totalSeconds % 60;
        return String.format(Locale.getDefault(), "%d:%02d", minutes, seconds);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (player != null) player.setPlayWhenReady(false);
    }

    @Override
    protected void onDestroy() {
        progressHandler.removeCallbacks(progressUpdater);
        if (player != null) {
            player.release();
            player = null;
        }
        super.onDestroy();
    }
}
