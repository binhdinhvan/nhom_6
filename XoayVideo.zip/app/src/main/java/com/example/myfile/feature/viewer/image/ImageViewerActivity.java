package com.example.myfile.feature.viewer.image;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;

import com.example.myfile.R;
import com.example.myfile.feature.viewer.ViewerFactory;
import com.example.myfile.utils.FileUtils;

import java.io.File;
import java.util.ArrayList;

/**
 * [C] Xem anh toan man hinh: pinch-zoom (PhotoView) + vuot trai/phai qua anh khac
 * trong cung thu muc (ViewPager2). Co nut xem EXIF va chia se anh.
 */
public class ImageViewerActivity extends AppCompatActivity {

    private static final String EXTRA_START_PATH = "extra_start_path";
    private static final String EXTRA_IMAGE_PATHS = "extra_image_paths";

    private ArrayList<String> imagePaths;
    private TextView tvTitle;
    private TextView tvCounter;
    private ViewPager2 viewPager;

    public static void start(Context context, String clickedPath, ArrayList<String> siblingImagePaths) {
        Intent intent = new Intent(context, ImageViewerActivity.class);
        if (siblingImagePaths == null || siblingImagePaths.isEmpty()) {
            siblingImagePaths = new ArrayList<>();
            siblingImagePaths.add(clickedPath);
        }
        intent.putExtra(EXTRA_START_PATH, clickedPath);
        intent.putStringArrayListExtra(EXTRA_IMAGE_PATHS, siblingImagePaths);
        context.startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_viewer);

        imagePaths = getIntent().getStringArrayListExtra(EXTRA_IMAGE_PATHS);
        if (imagePaths == null) imagePaths = new ArrayList<>();
        String startPath = getIntent().getStringExtra(EXTRA_START_PATH);

        tvTitle = findViewById(R.id.tvImageTitle);
        tvCounter = findViewById(R.id.tvImageCounter);
        viewPager = findViewById(R.id.viewPager);

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        findViewById(R.id.btnShare).setOnClickListener(v -> shareCurrentImage());
        findViewById(R.id.btnExif).setOnClickListener(v -> ViewerFactory.openExif(this, currentPath()));

        ImagePagerAdapter adapter = new ImagePagerAdapter(imagePaths);
        viewPager.setAdapter(adapter);

        int startIndex = Math.max(0, imagePaths.indexOf(startPath));
        viewPager.setCurrentItem(startIndex, false);
        updateHeader(startIndex);

        viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                updateHeader(position);
            }
        });
    }

    private void updateHeader(int position) {
        if (imagePaths.isEmpty()) return;
        tvTitle.setText(new File(imagePaths.get(position)).getName());
        tvCounter.setText((position + 1) + " / " + imagePaths.size());
    }

    private String currentPath() {
        return imagePaths.get(viewPager.getCurrentItem());
    }

    private void shareCurrentImage() {
        try {
            File file = new File(currentPath());
            Uri uri = FileUtils.contentUriFor(this, file);
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("image/*");
            share.putExtra(Intent.EXTRA_STREAM, uri);
            share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(share, "Share image"));
        } catch (Exception e) {
            Toast.makeText(this, "Unable to share this file", Toast.LENGTH_SHORT).show();
        }
    }
}
