package com.example.myfile.feature.viewer.exif;

import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myfile.R;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** [C] Man hinh xem metadata EXIF cua 1 anh. Doc file tren background thread rieng. */
public class ExifViewerActivity extends AppCompatActivity {

    public static final String EXTRA_FILE_PATH = "extra_file_path";

    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exif_viewer);

        String path = getIntent().getStringExtra(EXTRA_FILE_PATH);
        findViewById(R.id.btnExifBack).setOnClickListener(v -> finish());

        RecyclerView recyclerView = findViewById(R.id.recyclerViewExif);
        View tvEmpty = findViewById(R.id.tvExifEmpty);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        executor.execute(() -> {
            List<ExifReader.Entry> entries = ExifReader.read(path);
            runOnUiThread(() -> {
                if (entries.isEmpty()) {
                    tvEmpty.setVisibility(View.VISIBLE);
                    recyclerView.setVisibility(View.GONE);
                } else {
                    recyclerView.setAdapter(new ExifAdapter(entries));
                }
            });
        });
    }

    @Override
    protected void onDestroy() {
        executor.shutdown();
        super.onDestroy();
    }
}
