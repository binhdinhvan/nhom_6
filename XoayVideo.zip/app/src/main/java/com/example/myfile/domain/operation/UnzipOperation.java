package com.example.myfile.domain.operation;

import com.example.myfile.utils.FileUtils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * [C] Giai nen 1 file .zip vao 1 thu muc con moi ben trong thu muc dang duyet.
 * - Neu thu muc dich da ton tai, tu dong doi ten khac thay vi merge/ghi de.
 * - Zip Slip: huy toan bo + xoa thu muc dang giai nen do khi phat hien entry bat thuong,
 *   thay vi chi bo qua rieng entry do va tiep tuc (an toan hon).
 */
public class UnzipOperation implements FileOperation {
    private final String zipFilePath;
    private final String parentDirPath;

    /**
     * @param parentDirPath thu muc dang duyet (KHONG bao gom ten thu muc con se tao ra) -
     *                       vd truyen currentPath, khong phai currentPath + "/tenzip".
     */
    public UnzipOperation(String zipFilePath, String parentDirPath) {
        this.zipFilePath = zipFilePath;
        this.parentDirPath = parentDirPath;
    }

    @Override
    public boolean execute() {
        String desiredName = new File(zipFilePath).getName().replace(".zip", "");
        String uniqueName = FileUtils.uniqueName(new File(parentDirPath), desiredName);
        File targetDir = new File(parentDirPath, uniqueName);
        if (!targetDir.exists()) {
            targetDir.mkdirs();
        }

        try (ZipFile zipFile = new ZipFile(zipFilePath)) {
            Enumeration<? extends ZipEntry> entries = zipFile.entries();

            while (entries.hasMoreElements()) {
                ZipEntry entry = entries.nextElement();
                File entryDestination = new File(targetDir, entry.getName());

                // Chong Zip Slip
                String destDirPath = targetDir.getCanonicalPath();
                String destFilePath = entryDestination.getCanonicalPath();
                if (!destFilePath.startsWith(destDirPath + File.separator)) {
                    throw new SecurityException("Zip Slip detected: " + entry.getName());
                }

                if (entry.isDirectory()) {
                    entryDestination.mkdirs();
                } else {
                    entryDestination.getParentFile().mkdirs();
                    try (InputStream in = zipFile.getInputStream(entry);
                         FileOutputStream out = new FileOutputStream(entryDestination)) {

                        byte[] buffer = new byte[4096];
                        int len;
                        while ((len = in.read(buffer)) >= 0) {
                            out.write(buffer, 0, len);
                        }
                    }
                }
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            deleteRecursive(targetDir); // dep don thu muc giai nen dang do do loi/Zip Slip
            return false;
        }
    }

    private void deleteRecursive(File fileOrDirectory) {
        if (fileOrDirectory.isDirectory()) {
            File[] children = fileOrDirectory.listFiles();
            if (children != null) {
                for (File child : children) {
                    deleteRecursive(child);
                }
            }
        }
        fileOrDirectory.delete();
    }
}
