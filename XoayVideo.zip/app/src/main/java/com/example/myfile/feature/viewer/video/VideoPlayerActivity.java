package com.example.myfile.feature.viewer.video;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;

import com.example.myfile.R;
import com.example.myfile.utils.FileUtils;
import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.MediaItem;
import com.google.android.exoplayer2.ui.PlayerView;

import java.io.File;
import java.util.ArrayList;

/**
 * [C] Phat video bang ExoPlayer, vuot trai/phai de chuyen giua cac video khac
 * trong cung thu muc (giong ImageViewerActivity - dung ViewPager2 thay vi nut Next/Previous).
 * Chi dung 1 ExoPlayer duy nhat, gan/go vao PlayerView cua trang dang hien.
 */
public class VideoPlayerActivity extends AppCompatActivity {

    private static final String EXTRA_START_PATH = "extra_start_path";
    private static final String EXTRA_VIDEO_PATHS = "extra_video_paths";

    private ArrayList<String> videoPaths;
    private ExoPlayer player;
    private ViewPager2 viewPager;
    private VideoPagerAdapter adapter;
    private TextView tvTitle;
    private TextView tvCounter;
    private int pendingAttachPosition = -1;

    public static void start(Context context, String clickedPath, ArrayList<String> siblingVideoPaths) {
        Intent intent = new Intent(context, VideoPlayerActivity.class);
        if (siblingVideoPaths == null || siblingVideoPaths.isEmpty()) {
            siblingVideoPaths = new ArrayList<>();
            siblingVideoPaths.add(clickedPath);
        }
        intent.putExtra(EXTRA_START_PATH, clickedPath);
        intent.putStringArrayListExtra(EXTRA_VIDEO_PATHS, siblingVideoPaths);
        context.startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_player);

        videoPaths = getIntent().getStringArrayListExtra(EXTRA_VIDEO_PATHS);
        if (videoPaths == null) videoPaths = new ArrayList<>();
        String startPath = getIntent().getStringExtra(EXTRA_START_PATH);

        tvTitle = findViewById(R.id.tvVideoTitle);
        tvCounter = findViewById(R.id.tvVideoCounter);
        viewPager = findViewById(R.id.viewPager);

        findViewById(R.id.btnVideoBack).setOnClickListener(v -> finish());
        findViewById(R.id.btnVideoRotate).setOnClickListener(v -> toggleOrientation());

        adapter = new VideoPagerAdapter(videoPaths);
        viewPager.setAdapter(adapter);
        viewPager.setOffscreenPageLimit(1);

        player = new ExoPlayer.Builder(this).build();

        int startIndex = Math.max(0, videoPaths.indexOf(startPath));
        viewPager.setCurrentItem(startIndex, false);
        attachPlayer(startIndex);

        viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                attachPlayer(position);
            }
        });
    }

    private void attachPlayer(int position) {
        if (videoPaths.isEmpty()) return;
        PlayerView playerView = adapter.playerViewAt(position);
        if (playerView == null) {
            pendingAttachPosition = position;
            viewPager.post(() -> {
                if (pendingAttachPosition == position) {
                    attachPlayer(position);
                }
            });
            return;
        }
        pendingAttachPosition = -1;

        playerView.setPlayer(player);

        String path = videoPaths.get(position);
        File file = new File(path);
        tvTitle.setText(file.getName());
        tvCounter.setText((position + 1) + " / " + videoPaths.size());

        Uri uri = FileUtils.contentUriFor(this, file);
        player.setMediaItem(MediaItem.fromUri(uri));
        player.prepare();
        player.setPlayWhenReady(true);
    }

    private void toggleOrientation() {
        boolean isLandscape = getResources().getConfiguration().orientation
                == android.content.res.Configuration.ORIENTATION_LANDSCAPE;
        setRequestedOrientation(isLandscape
                ? android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                : android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (player != null) player.setPlayWhenReady(false);
    }

    @Override
    protected void onDestroy() {
        if (player != null) {
            player.release();
            player = null;
        }
        super.onDestroy();
    }
}
