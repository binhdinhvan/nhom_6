package com.example.myfile.feature.viewer.exif;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myfile.R;

import java.util.List;

/** [C] Hien danh sach cac dong EXIF (nhan + gia tri) dang RecyclerView. */
public class ExifAdapter extends RecyclerView.Adapter<ExifAdapter.RowViewHolder> {

    private final List<ExifReader.Entry> entries;

    public ExifAdapter(List<ExifReader.Entry> entries) {
        this.entries = entries;
    }

    @NonNull
    @Override
    public RowViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_exif_row, parent, false);
        return new RowViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RowViewHolder holder, int position) {
        ExifReader.Entry entry = entries.get(position);
        holder.tvLabel.setText(entry.label);
        holder.tvValue.setText(entry.value);
    }

    @Override
    public int getItemCount() {
        return entries.size();
    }

    static class RowViewHolder extends RecyclerView.ViewHolder {
        final TextView tvLabel;
        final TextView tvValue;

        RowViewHolder(View itemView) {
            super(itemView);
            tvLabel = itemView.findViewById(R.id.tvExifLabel);
            tvValue = itemView.findViewById(R.id.tvExifValue);
        }
    }
}
