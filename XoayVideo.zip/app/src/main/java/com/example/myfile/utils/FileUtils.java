package com.example.myfile.utils;

import android.content.Context;
import android.net.Uri;
import androidx.core.content.FileProvider;

import java.io.File;

/** [C] Ham dung chung: lay content:// URI qua FileProvider, va sinh ten khong trung khi da ton tai. */
public class FileUtils {

    public static Uri contentUriFor(Context context, File file) {
        return FileProvider.getUriForFile(context, context.getPackageName() + ".fileprovider", file);
    }

    /**
     * Neu new File(parentDir, desiredName) da ton tai, tra ve ten khac dang "name (1).ext",
     * "name (2).ext"... Neu chua ton tai, tra ve nguyen desiredName.
     * Dung duoc cho ca file (co duoi) va thu muc (khong duoi).
     */
    public static String uniqueName(File parentDir, String desiredName) {
        File target = new File(parentDir, desiredName);
        if (!target.exists()) return desiredName;

        int dot = desiredName.lastIndexOf('.');
        String base = dot > 0 ? desiredName.substring(0, dot) : desiredName;
        String ext = dot > 0 ? desiredName.substring(dot) : "";

        int counter = 1;
        File candidate;
        do {
            candidate = new File(parentDir, base + " (" + counter + ")" + ext);
            counter++;
        } while (candidate.exists());
        return candidate.getName();
    }
}
