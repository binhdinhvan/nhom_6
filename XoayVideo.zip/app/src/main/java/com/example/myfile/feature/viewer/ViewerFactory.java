package com.example.myfile.feature.viewer;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;

import com.example.myfile.data.model.FileItem;
import com.example.myfile.feature.viewer.exif.ExifViewerActivity;
import com.example.myfile.feature.viewer.image.ImageViewerActivity;
import com.example.myfile.feature.viewer.text.TextViewerActivity;
import com.example.myfile.feature.viewer.video.VideoPlayerActivity;
import com.example.myfile.utils.FileUtils;
import com.example.myfile.utils.MimeUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * [C] Factory - dieu huong 1 FileItem duoc bam vao viewer phu hop theo loai file:
 * anh/video/text mo bang viewer rieng trong app (co the vuot qua file khac cung thu muc),
 * cac loai con lai (pdf, apk, docx...) mo bang app he thong qua ACTION_VIEW.
 */
public class ViewerFactory {

    public static void open(Context context, FileItem clicked, List<FileItem> siblingsInFolder) {
        MimeUtils.Category category = MimeUtils.categoryOf(clicked.getName());

        switch (category) {
            case IMAGE: {
                ArrayList<String> imagePaths = collectPaths(siblingsInFolder, MimeUtils.Category.IMAGE);
                ImageViewerActivity.start(context, clicked.getPath(), imagePaths);
                break;
            }
            case VIDEO: {
                ArrayList<String> videoPaths = collectPaths(siblingsInFolder, MimeUtils.Category.VIDEO);
                VideoPlayerActivity.start(context, clicked.getPath(), videoPaths);
                break;
            }
            case AUDIO: {
                ArrayList<String> audioPaths = collectPaths(siblingsInFolder, MimeUtils.Category.AUDIO);
                com.example.myfile.feature.viewer.audio.AudioPlayerActivity.start(context, clicked.getPath(), audioPaths);
                break;
            }
            case TEXT: {
                Intent intent = new Intent(context, TextViewerActivity.class);
                intent.putExtra(TextViewerActivity.EXTRA_FILE_PATH, clicked.getPath());
                context.startActivity(intent);
                break;
            }
            default:
                openWithSystemApp(context, clicked);
        }
    }

    public static void openExif(Context context, String imagePath) {
        Intent intent = new Intent(context, ExifViewerActivity.class);
        intent.putExtra(ExifViewerActivity.EXTRA_FILE_PATH, imagePath);
        context.startActivity(intent);
    }

    private static ArrayList<String> collectPaths(List<FileItem> items, MimeUtils.Category category) {
        ArrayList<String> result = new ArrayList<>();
        if (items == null) return result;
        for (FileItem item : items) {
            if (!item.isDirectory() && MimeUtils.categoryOf(item.getName()) == category) {
                result.add(item.getPath());
            }
        }
        return result;
    }

    private static void openWithSystemApp(Context context, FileItem item) {
        try {
            File file = new File(item.getPath());
            Uri uri = FileUtils.contentUriFor(context, file);
            String mimeType = MimeUtils.mimeTypeOf(item.getName());

            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(uri, mimeType);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            context.startActivity(Intent.createChooser(intent, "Open with"));
        } catch (Exception e) {
            Toast.makeText(context, "No suitable app found to open this file", Toast.LENGTH_SHORT).show();
        }
    }
}
