package com.example.myfile.feature.viewer.exif;

import androidx.exifinterface.media.ExifInterface;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** [C] Doc metadata EXIF cua 1 file anh, tach rieng khoi Activity de de test. */
public class ExifReader {

    public static class Entry {
        public final String label;
        public final String value;
        public Entry(String label, String value) { this.label = label; this.value = value; }
    }

    private static final Map<String, String> TAG_LABELS = new LinkedHashMap<>();
    static {
        TAG_LABELS.put(ExifInterface.TAG_DATETIME, "Date taken");
        TAG_LABELS.put(ExifInterface.TAG_MAKE, "Camera make");
        TAG_LABELS.put(ExifInterface.TAG_MODEL, "Camera model");
        TAG_LABELS.put(ExifInterface.TAG_IMAGE_WIDTH, "Width (px)");
        TAG_LABELS.put(ExifInterface.TAG_IMAGE_LENGTH, "Height (px)");
        TAG_LABELS.put(ExifInterface.TAG_F_NUMBER, "Aperture (f)");
        TAG_LABELS.put(ExifInterface.TAG_EXPOSURE_TIME, "Shutter speed");
        TAG_LABELS.put(ExifInterface.TAG_ISO_SPEED_RATINGS, "ISO");
        TAG_LABELS.put(ExifInterface.TAG_FOCAL_LENGTH, "Focal length");
        TAG_LABELS.put(ExifInterface.TAG_WHITE_BALANCE, "White balance");
        TAG_LABELS.put(ExifInterface.TAG_FLASH, "Flash");
    }

    public static List<Entry> read(String imagePath) {
        List<Entry> result = new ArrayList<>();
        try {
            ExifInterface exif = new ExifInterface(imagePath);
            for (Map.Entry<String, String> tag : TAG_LABELS.entrySet()) {
                String value = exif.getAttribute(tag.getKey());
                if (value != null && !value.trim().isEmpty()) {
                    result.add(new Entry(tag.getValue(), value));
                }
            }
            float[] latLong = new float[2];
            if (exif.getLatLong(latLong)) {
                result.add(new Entry("Latitude", String.valueOf(latLong[0])));
                result.add(new Entry("Longitude", String.valueOf(latLong[1])));
            }
        } catch (IOException e) {
            result.add(new Entry("Error", "Failed to read metadata: " + e.getMessage()));
        }
        return result;
    }
}
