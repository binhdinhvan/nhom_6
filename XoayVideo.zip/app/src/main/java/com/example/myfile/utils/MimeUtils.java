package com.example.myfile.utils;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/** [C] Phan loai file theo phan mo rong, dung de dieu huong ViewerFactory va sinh MIME type khi share/open. */
public class MimeUtils {

    public enum Category { IMAGE, VIDEO, AUDIO, TEXT, OTHER }

    private static final Set<String> IMAGE_EXT = new HashSet<>(Arrays.asList(
            "jpg", "jpeg", "png", "gif", "bmp", "webp", "heic"));
    private static final Set<String> VIDEO_EXT = new HashSet<>(Arrays.asList(
            "mp4", "mkv", "3gp", "webm", "mov", "avi"));
    private static final Set<String> AUDIO_EXT = new HashSet<>(Arrays.asList(
            "mp3", "wav", "m4a", "aac", "flac", "ogg", "wma", "opus"));
    private static final Set<String> TEXT_EXT = new HashSet<>(Arrays.asList(
            "txt", "log", "md", "json", "xml", "csv"));

    public static Category categoryOf(String fileName) {
        String ext = extensionOf(fileName);
        if (IMAGE_EXT.contains(ext)) return Category.IMAGE;
        if (VIDEO_EXT.contains(ext)) return Category.VIDEO;
        if (AUDIO_EXT.contains(ext)) return Category.AUDIO;
        if (TEXT_EXT.contains(ext)) return Category.TEXT;
        return Category.OTHER;
    }

    public static String extensionOf(String fileName) {
        int dot = fileName.lastIndexOf('.');
        if (dot < 0 || dot == fileName.length() - 1) return "";
        return fileName.substring(dot + 1).toLowerCase();
    }

    public static String mimeTypeOf(String fileName) {
        String ext = extensionOf(fileName);
        String mime = android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
        return mime != null ? mime : "*/*";
    }
}
