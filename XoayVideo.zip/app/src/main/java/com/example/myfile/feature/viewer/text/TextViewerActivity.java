package com.example.myfile.feature.viewer.text;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myfile.R;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** [C] Xem nhanh noi dung file text (.txt, .log, .md...). Gioi han doc toi da 2MB de tranh treo UI. */
public class TextViewerActivity extends AppCompatActivity {

    public static final String EXTRA_FILE_PATH = "extra_file_path";
    private static final long MAX_READ_BYTES = 2 * 1024 * 1024;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_text_viewer);

        String path = getIntent().getStringExtra(EXTRA_FILE_PATH);
        TextView tvTitle = findViewById(R.id.tvTextTitle);
        TextView tvContent = findViewById(R.id.tvTextContent);
        View progressBar = findViewById(R.id.progressText);

        tvTitle.setText(new java.io.File(path).getName());
        findViewById(R.id.btnTextBack).setOnClickListener(v -> finish());

        executor.execute(() -> {
            String content;
            try (BufferedReader reader = new BufferedReader(new FileReader(path))) {
                StringBuilder sb = new StringBuilder();
                char[] buffer = new char[4096];
                long totalRead = 0;
                int len;
                while ((len = reader.read(buffer)) > 0) {
                    sb.append(buffer, 0, len);
                    totalRead += len;
                    if (totalRead > MAX_READ_BYTES) {
                        sb.append("\n\n--- (Truncated, file too large) ---");
                        break;
                    }
                }
                content = sb.toString();
            } catch (IOException e) {
                content = "Failed to read file: " + e.getMessage();
            }
            String finalContent = content;
            mainHandler.post(() -> {
                progressBar.setVisibility(View.GONE);
                tvContent.setText(finalContent.isEmpty() ? "(Empty file)" : finalContent);
            });
        });
    }

    @Override
    protected void onDestroy() {
        executor.shutdown();
        super.onDestroy();
    }
}
