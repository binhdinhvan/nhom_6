package com.example.myfile.domain.operation;

import com.example.myfile.utils.FileUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * [C] Nen nhieu file/thu muc (hoac 1) thanh 1 file .zip.
 * - Ho tro nen nhieu nguon cung luc.
 * - Bo qua file an.
 * - Neu ten .zip da ton tai, tu dong doi ten khac (vd "backup (1).zip") thay vi ghi de.
 */
public class ZipOperation implements FileOperation {
    private final List<String> sourcePaths;
    private final String desiredZipPath;

    public ZipOperation(List<String> sourcePaths, String desiredZipPath) {
        this.sourcePaths = sourcePaths;
        this.desiredZipPath = desiredZipPath;
    }

    @Override
    public boolean execute() {
        File desired = new File(desiredZipPath);
        File parentDir = desired.getParentFile();
        String uniqueName = FileUtils.uniqueName(parentDir, desired.getName());
        File destZip = new File(parentDir, uniqueName);

        try (FileOutputStream fos = new FileOutputStream(destZip);
             ZipOutputStream zos = new ZipOutputStream(fos)) {

            for (String sourcePath : sourcePaths) {
                File srcFile = new File(sourcePath);
                zipFile(srcFile, srcFile.getName(), zos);
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            destZip.delete(); // xoa file zip dang do do loi giua chung
            return false;
        }
    }

    private void zipFile(File fileToZip, String fileName, ZipOutputStream zos) throws IOException {
        if (fileToZip.isHidden()) {
            return;
        }
        if (fileToZip.isDirectory()) {
            zos.putNextEntry(new ZipEntry(fileName.endsWith("/") ? fileName : fileName + "/"));
            zos.closeEntry();
            File[] children = fileToZip.listFiles();
            if (children != null) {
                for (File childFile : children) {
                    zipFile(childFile, fileName + "/" + childFile.getName(), zos);
                }
            }
            return;
        }

        try (FileInputStream fis = new FileInputStream(fileToZip)) {
            zos.putNextEntry(new ZipEntry(fileName));
            byte[] bytes = new byte[4096];
            int length;
            while ((length = fis.read(bytes)) >= 0) {
                zos.write(bytes, 0, length);
            }
        }
    }
}
