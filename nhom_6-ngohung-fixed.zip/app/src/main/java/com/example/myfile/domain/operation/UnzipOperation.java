package com.example.myfile.domain.operation;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

import com.example.myfile.feature.archive.ArchiveDialogs;
import com.example.myfile.utils.FileUtils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * [C] Giai nen 1 file .zip vao 1 thu muc con moi ben trong thu muc dang duyet.
 * - Hoi xac nhan dich den truoc khi giai nen.
 * - Tu dong doi ten thu muc dich neu da ton tai, KHONG merge/ghi de - dung chung
 *   FileUtils.uniqueName() thay vi tu viet lai (truoc day tinh sai duong dan long 2 cap).
 * - Zip Slip: huy toan bo + xoa thu muc giai nen do khi phat hien entry bat thuong.
 */
public class UnzipOperation {

    /**
     * @param parentDirPath thu muc dang duyet (KHONG bao gom ten thu muc con se tao ra) -
     *                       vd truyen currentPath, khong phai currentPath + "/tenzip".
     * @param onDone chay tren UI thread sau khi xong (thanh cong hoac that bai) de MainActivity
     *               lam moi danh sach file.
     */
    public void extractFile(Context context, String zipFilePath, String parentDirPath, Runnable onDone) {
        String desiredName = new File(zipFilePath).getName().replace(".zip", "");
        String uniqueName = FileUtils.uniqueName(new File(parentDirPath), desiredName);
        File targetDir = new File(parentDirPath, uniqueName);

        // Hien dialog xac nhan dich den truoc khi giai nen (cua Part C)
        ArchiveDialogs.showExtractConfirmDialog(context, targetDir.getAbsolutePath(), () -> {
            ProgressDialog progressDialog = ArchiveDialogs.showProgressDialog(context, "Extracting...");

            new Thread(() -> {
                try {
                    if (!targetDir.exists()) targetDir.mkdirs();

                    try (ZipFile zipFile = new ZipFile(zipFilePath)) {
                        Enumeration<? extends ZipEntry> entries = zipFile.entries();
                        while (entries.hasMoreElements()) {
                            ZipEntry entry = entries.nextElement();

                            // Kiem tra Zip Slip chat che
                            if (entry.getName().contains("../") || entry.getName().contains("..\\")) {
                                throw new SecurityException("Zip Slip detected");
                            }
                            File entryDest = new File(targetDir, entry.getName());
                            if (!entryDest.getCanonicalPath().startsWith(targetDir.getCanonicalPath() + File.separator)) {
                                throw new SecurityException("Zip Slip detected");
                            }

                            if (entry.isDirectory()) {
                                entryDest.mkdirs();
                            } else {
                                entryDest.getParentFile().mkdirs();
                                try (InputStream is = zipFile.getInputStream(entry);
                                     FileOutputStream fos = new FileOutputStream(entryDest)) {
                                    byte[] buffer = new byte[4096];
                                    int length;
                                    while ((length = is.read(buffer)) > 0) {
                                        fos.write(buffer, 0, length);
                                    }
                                }
                            }
                        }
                    }

                    final String finalDirName = targetDir.getName();
                    new Handler(Looper.getMainLooper()).post(() -> {
                        progressDialog.dismiss();
                        Toast.makeText(context, "Extracted successfully into: " + finalDirName, Toast.LENGTH_SHORT).show();
                        if (onDone != null) onDone.run();
                    });

                } catch (SecurityException e) {
                    new Handler(Looper.getMainLooper()).post(() -> {
                        progressDialog.dismiss();
                        Toast.makeText(context, "Security error (Zip Slip). Extraction cancelled.", Toast.LENGTH_LONG).show();
                        if (targetDir.exists()) {
                            deleteRecursive(targetDir); // xoa thu muc giai nen do
                        }
                        if (onDone != null) onDone.run();
                    });
                } catch (Exception e) {
                    new Handler(Looper.getMainLooper()).post(() -> {
                        progressDialog.dismiss();
                        Toast.makeText(context, "Extraction failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        if (onDone != null) onDone.run();
                    });
                }
            }).start();
        });
    }

    private void deleteRecursive(File fileOrDirectory) {
        if (fileOrDirectory.isDirectory()) {
            File[] children = fileOrDirectory.listFiles();
            if (children != null) {
                for (File child : children) {
                    deleteRecursive(child);
                }
            }
        }
        fileOrDirectory.delete();
    }
}
