package com.example.myfile.domain.operation;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

import com.example.myfile.feature.archive.ArchiveDialogs;
import com.example.myfile.feature.archive.ArchiveUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * [C] Nen nhieu file/thu muc (hoac 1) thanh 1 file .zip.
 * - Ho tro nen nhieu nguon cung luc (uu diem cua ban Zip moi).
 * - Tu dong doi ten neu file .zip da ton tai, KHONG ghi de (uu diem cua ban Zip cu),
 *   dung chung logic voi ArchiveUtils.uniqueZipName() thay vi tu viet lai.
 * - Bo qua file an.
 */
public class ZipOperation {

    /**
     * @param desiredZipPath duong dan zip mong muon nguoi dung go, vd ".../Download/backup.zip".
     *                        Ten thuc te co the bi doi thanh "backup (1).zip"... neu da ton tai.
     * @param onDone chay tren UI thread sau khi xong (thanh cong hoac that bai) de MainActivity
     *               lam moi danh sach file.
     */
    public void compressFiles(Context context, List<String> sourcePaths, String desiredZipPath, Runnable onDone) {
        ProgressDialog progressDialog = ArchiveDialogs.showProgressDialog(context, "Compressing...");
        new Thread(() -> {
            try {
                File desired = new File(desiredZipPath);
                File parentDir = desired.getParentFile();
                String uniqueName = ArchiveUtils.uniqueZipName(parentDir, desired.getName());
                File destZip = new File(parentDir, uniqueName);

                try (ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(destZip))) {
                    for (String sourcePath : sourcePaths) {
                        File sourceFile = new File(sourcePath);
                        if (sourceFile.isHidden()) continue; // bo qua file an
                        addFileToZip(sourceFile, sourceFile.getName(), zos);
                    }
                }

                new Handler(Looper.getMainLooper()).post(() -> {
                    progressDialog.dismiss();
                    Toast.makeText(context, "Zipped successfully: " + destZip.getName(), Toast.LENGTH_SHORT).show();
                    if (onDone != null) onDone.run();
                });
            } catch (SecurityException e) {
                new Handler(Looper.getMainLooper()).post(() -> {
                    progressDialog.dismiss();
                    Toast.makeText(context, "Unsafe entry detected (Zip Slip). Compression cancelled.", Toast.LENGTH_LONG).show();
                    if (onDone != null) onDone.run();
                });
            } catch (Exception e) {
                new Handler(Looper.getMainLooper()).post(() -> {
                    progressDialog.dismiss();
                    Toast.makeText(context, "Zip failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    if (onDone != null) onDone.run();
                });
            }
        }).start();
    }

    private void addFileToZip(File file, String entryName, ZipOutputStream zos) throws Exception {
        // Bao ve Zip Slip
        if (entryName.contains("../") || entryName.contains("..\\")) {
            throw new SecurityException("Zip Slip detected");
        }

        if (file.isDirectory()) {
            if (!entryName.endsWith("/")) entryName += "/";
            zos.putNextEntry(new ZipEntry(entryName));
            zos.closeEntry();
            File[] children = file.listFiles();
            if (children != null) {
                for (File child : children) {
                    addFileToZip(child, entryName + child.getName(), zos);
                }
            }
        } else {
            try (FileInputStream fis = new FileInputStream(file)) {
                zos.putNextEntry(new ZipEntry(entryName));
                byte[] buffer = new byte[4096];
                int length;
                while ((length = fis.read(buffer)) > 0) {
                    zos.write(buffer, 0, length);
                }
                zos.closeEntry();
            }
        }
    }
}
