package com.example.myfile.feature.archive;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;

public class ArchiveDialogs {
    public static ProgressDialog showProgressDialog(Context context, String message) {
        ProgressDialog progressDialog = new ProgressDialog(context);
        progressDialog.setMessage(message);
        progressDialog.setCancelable(false);
        progressDialog.show();
        return progressDialog;
    }

    public static void showExtractConfirmDialog(Context context, String destPath, Runnable onConfirm) {
        new AlertDialog.Builder(context)
            .setTitle("Confirm extraction")
            .setMessage("Extract into:\n\n" + destPath + " ?")
            .setPositiveButton("Extract", (dialog, which) -> onConfirm.run())
            .setNegativeButton("Cancel", null)
            .show();
    }
}
