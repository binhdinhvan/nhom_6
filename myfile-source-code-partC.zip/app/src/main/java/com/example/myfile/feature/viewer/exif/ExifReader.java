package com.example.myfile.feature.viewer.exif;

import androidx.exifinterface.media.ExifInterface;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** [C] Doc cac tag EXIF pho bien tu 1 file anh, tra ve danh sach da gan nhan. */
public final class ExifReader {

    public static class Entry {
        public final String label;
        public final String value;

        public Entry(String label, String value) {
            this.label = label;
            this.value = value;
        }
    }

    private ExifReader() { }

    public static List<Entry> read(File imageFile) {
        List<Entry> result = new ArrayList<>();
        try {
            ExifInterface exif = new ExifInterface(imageFile.getAbsolutePath());
            for (Map.Entry<String, String> tag : labels().entrySet()) {
                String value = exif.getAttribute(tag.getKey());
                if (value != null && !value.trim().isEmpty()) {
                    result.add(new Entry(tag.getValue(), value));
                }
            }
            double[] latLong = exif.getLatLong();
            if (latLong != null) {
                result.add(new Entry("Vi do", String.valueOf(latLong[0])));
                result.add(new Entry("Kinh do", String.valueOf(latLong[1])));
            }
        } catch (IOException e) {
            result.add(new Entry("Loi", "Khong doc duoc metadata: " + e.getMessage()));
        }
        return result;
    }

    private static Map<String, String> labels() {
        Map<String, String> map = new LinkedHashMap<>();
        map.put(ExifInterface.TAG_DATETIME, "Ngay chup");
        map.put(ExifInterface.TAG_MAKE, "Hang may");
        map.put(ExifInterface.TAG_MODEL, "Model may");
        map.put(ExifInterface.TAG_IMAGE_WIDTH, "Chieu rong (px)");
        map.put(ExifInterface.TAG_IMAGE_LENGTH, "Chieu cao (px)");
        map.put(ExifInterface.TAG_F_NUMBER, "Khau do (f)");
        map.put(ExifInterface.TAG_EXPOSURE_TIME, "Toc do mang trap");
        map.put(ExifInterface.TAG_ISO_SPEED_RATINGS, "ISO");
        map.put(ExifInterface.TAG_FOCAL_LENGTH, "Tieu cu");
        map.put(ExifInterface.TAG_WHITE_BALANCE, "Can bang trang");
        map.put(ExifInterface.TAG_FLASH, "Flash");
        return map;
    }
}
