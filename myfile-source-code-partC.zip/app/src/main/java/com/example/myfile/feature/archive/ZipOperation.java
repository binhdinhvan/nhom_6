package com.example.myfile.feature.archive;

import com.example.myfile.domain.operation.FileOperation;
import com.example.myfile.util.FileUtils;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Nen 1 file/thu muc thanh file .zip trong destDirPath.
 * Cung mo hinh Command pattern nhu RenameOperation/DeleteOperation... cua B:
 * implement FileOperation.execute() -> boolean, khong ngoai le, khong tien do
 * (du an chua co co che progress/callback dung chung).
 */
public class ZipOperation implements FileOperation {

    private final String sourcePath;
    private final String destDirPath;
    private final String zipFileName;
    private String resultZipPath;

    public ZipOperation(String sourcePath, String destDirPath, String zipFileName) {
        this.sourcePath = sourcePath;
        this.destDirPath = destDirPath;
        this.zipFileName = zipFileName;
    }

    /** Duong dan file .zip vua tao, chi co gia tri sau khi execute() tra ve true. */
    public String getResultZipPath() {
        return resultZipPath;
    }

    @Override
    public boolean execute() {
        File source = new File(sourcePath);
        File destDir = new File(destDirPath);
        if (!source.exists() || (!destDir.exists() && !destDir.mkdirs())) {
            return false;
        }

        String uniqueName = ArchiveUtils.uniqueZipName(destDir, zipFileName);
        File zipFile = new File(destDir, uniqueName);

        try (ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(zipFile))) {
            addToZip(zos, source, source.getName());
        } catch (IOException e) {
            //noinspection ResultOfMethodCallIgnored
            zipFile.delete();
            return false;
        }

        resultZipPath = zipFile.getAbsolutePath();
        return true;
    }

    private void addToZip(ZipOutputStream zos, File file, String entryPath) throws IOException {
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children == null || children.length == 0) {
                zos.putNextEntry(new ZipEntry(entryPath + "/"));
                zos.closeEntry();
                return;
            }
            for (File child : children) {
                addToZip(zos, child, entryPath + "/" + child.getName());
            }
            return;
        }

        try (BufferedInputStream in = new BufferedInputStream(new FileInputStream(file))) {
            zos.putNextEntry(new ZipEntry(entryPath));
            FileUtils.copyStream(in, zos);
            zos.closeEntry();
        }
    }
}
