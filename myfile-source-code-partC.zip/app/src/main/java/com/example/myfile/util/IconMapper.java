package com.example.myfile.util;

import androidx.annotation.DrawableRes;

import com.example.myfile.R;

/** [C] Anh xa Category (MimeUtils) -> icon hien thi. Co the dung o FileAdapter (B) neu muon. */
public final class IconMapper {

    private IconMapper() { }

    @DrawableRes
    public static int iconFor(MimeUtils.Category category) {
        switch (category) {
            case FOLDER: return R.drawable.ic_type_folder;
            case IMAGE: return R.drawable.ic_type_image;
            case VIDEO: return R.drawable.ic_type_video;
            case AUDIO: return R.drawable.ic_type_audio;
            case ARCHIVE: return R.drawable.ic_type_archive;
            case DOCUMENT: return R.drawable.ic_type_doc;
            case APK: return R.drawable.ic_type_apk;
            case TEXT: return R.drawable.ic_type_text;
            case OTHER:
            default: return R.drawable.ic_type_other;
        }
    }

    public static int iconFor(String fileName, boolean isDirectory) {
        return iconFor(MimeUtils.categoryOf(fileName, isDirectory));
    }
}
