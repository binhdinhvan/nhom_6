package com.example.myfile.feature.archive;

import com.example.myfile.domain.operation.FileOperation;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Giai nen 1 file .zip ra thu muc dich (mac dinh nen tao 1 thu muc con cung
 * ten file zip - do MainActivity truyen destDirPath, tu quyet dinh).
 */
public class UnzipOperation implements FileOperation {

    private final String zipFilePath;
    private final String destDirPath;

    public UnzipOperation(String zipFilePath, String destDirPath) {
        this.zipFilePath = zipFilePath;
        this.destDirPath = destDirPath;
    }

    @Override
    public boolean execute() {
        File zipFile = new File(zipFilePath);
        File destDir = new File(destDirPath);
        if (!zipFile.exists() || (!destDir.exists() && !destDir.mkdirs())) {
            return false;
        }

        try (ZipInputStream zis = new ZipInputStream(new FileInputStream(zipFile))) {
            ZipEntry entry;
            byte[] buffer = new byte[8192];

            while ((entry = zis.getNextEntry()) != null) {
                File outFile = safeTargetFile(destDir, entry.getName());
                if (outFile == null) {
                    return false; // entry co duong dan khong hop le (Zip Slip)
                }

                if (entry.isDirectory()) {
                    if (!outFile.exists() && !outFile.mkdirs()) {
                        return false;
                    }
                } else {
                    File parent = outFile.getParentFile();
                    if (parent != null && !parent.exists() && !parent.mkdirs()) {
                        return false;
                    }
                    try (BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(outFile))) {
                        int read;
                        while ((read = zis.read(buffer)) != -1) {
                            out.write(buffer, 0, read);
                        }
                    }
                }
                zis.closeEntry();
            }
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    /** Chan Zip Slip: entry co duong dan thoat khoi thu muc dich (vd "../../etc/passwd"). */
    private File safeTargetFile(File destDir, String entryName) throws IOException {
        File target = new File(destDir, entryName);
        String destPath = destDir.getCanonicalPath();
        String targetPath = target.getCanonicalPath();
        if (!targetPath.equals(destPath) && !targetPath.startsWith(destPath + File.separator)) {
            return null;
        }
        return target;
    }
}
