# My File - Source code (Thanh vien C - Xem noi dung & Nen/Giai nen)

File nay tong hop code phan C, viet de khop voi source code that cua nhom
(da xem qua MainActivity.java, FileItem.java, FileRepository... cua B truoc
khi viet, KHONG dung Hilt/ViewBinding/Material Components vi du an hien tai
chua dung nhung thu do).

## Cach dung

1. Copy toan bo `app/src/main/java/com/example/myfile/util/`,
   `app/src/main/java/com/example/myfile/feature/`, va cac file trong
   `app/src/main/res/layout/`, `res/drawable/`, `res/xml/` vao du an that.
2. File `MainActivity.java` trong ban nay **da duoc sua san** (them cac doan
   danh dau `// [C]`) de goi ViewerFactory khi tap vao file, va them 2 tuy
   chon "Zip"/"Unzip" vao menu long-click co san. Doi chieu voi
   MainActivity.java hien tai cua nhom (neu B da sua thanh cai gi khac thi
   merge tay, dung ghi de mu quang).
3. Mo `GRADLE_ADDITIONS_C.txt`, them cac dependency (Glide, PhotoView,
   ExoPlayer, exifinterface) vao `app/build.gradle.kts`.
4. Mo `MANIFEST_ADDITIONS_C.txt`, them 4 activity moi + FileProvider vao
   `AndroidManifest.xml` that.
5. Sync Gradle, build thu (Ctrl+F9).

## Danh sach file moi

- util/MimeUtils.java — phan loai file theo phan mo rong + doan MIME type
- util/IconMapper.java — Category -> icon
- util/FileUtils.java — copy stream, dem file de quy, sinh ten khong trung, Uri chia se
- feature/viewer/ViewerFactory.java — ⚑ Factory, route mo file theo loai
- feature/viewer/image/ImageViewerActivity.java + ImagePagerAdapter.java — Glide + PhotoView + ViewPager2
- feature/viewer/video/VideoPlayerActivity.java — ExoPlayer, Next/Previous trong cung thu muc
- feature/viewer/exif/ExifViewerActivity.java + ExifAdapter.java + ExifReader.java — doc EXIF
- feature/viewer/text/TextViewerActivity.java — xem noi dung file text (optional)
- feature/archive/ZipOperation.java, UnzipOperation.java — implement `FileOperation` (cung Command pattern voi Rename/Delete/Move/Copy cua B), co chong Zip Slip
- feature/archive/ArchiveUtils.java — dem entry, tinh size, sinh ten zip khong trung
- feature/archive/ArchiveDialogs.java — dialog nhap ten file zip (AlertDialog + EditText, cung phong cach voi showRenameDialog cua B)
- res/drawable/ic_type_*.xml — icon theo loai file
- res/xml/file_paths.xml — FileProvider paths

## Tinh nang da lam

- Tap vao anh -> mo ImageViewerActivity, vuot trai/phai giua cac anh cung
  thu muc, zoom bang PhotoView, nut xem EXIF va chia se.
- Tap vao video -> mo VideoPlayerActivity (ExoPlayer), nut Next/Previous
  giua cac video cung thu muc.
- Xem EXIF: ngay chup, may/model, kich thuoc, khau do, ISO, GPS...
- Xem nhanh file text (.txt/.log/.json/.md...).
- Nen 1 file/thu muc thanh .zip (long-click -> Zip -> nhap ten).
- Giai nen file .zip ngay trong thu muc hien tai (long-click file .zip ->
  Unzip). Co kiem tra chong Zip Slip (entry co duong dan doc hai).
- Cac loai file khac (PDF, DOCX, APK...) duoc giao cho app he thong mo qua
  FileProvider.

## Luu y ky thuat

- `FileItem` hien tai (cua B) chua implement Parcelable, nen cac Activity o
  day truyen du lieu qua Intent bang String path (khong truyen FileItem).
- Chua co lop AppExecutors/ViewModel dung chung trong du an, nen
  ExifViewerActivity/TextViewerActivity tu tao ExecutorService rieng va
  huy o onDestroy() de tranh chan UI thread khi doc file.
- Zip/Unzip chay dong bo (giong RenameOperation/DeleteOperation... cua B,
  khong co progress bar) — neu can progress cho file lon, se can nhom ban
  bac lai kien truc chung (vi du them AsyncTask/Executor + callback).

## Con thieu (co the lam tiep)

- Progress bar khi nen/giai nen file lon
- Multi-select de nen nhieu file cung luc (dang cho multi-select cua B)
